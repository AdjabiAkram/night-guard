"""
database.py - Accès à la base SQLite et système de migrations.

Principes :
- La base `gardes.db` n'est JAMAIS supprimée ni recréée automatiquement.
- Le schéma évolue uniquement via la liste MIGRATIONS (version stockée dans
  PRAGMA user_version). Pour une future mise à jour, il suffit d'AJOUTER une
  nouvelle entrée à la fin de la liste : les données existantes sont conservées.
- Avant d'appliquer une migration sur une base existante, une copie de
  sauvegarde est créée dans le dossier `backups/`.
"""
import os
import secrets
import sqlite3
from datetime import datetime

from werkzeug.security import generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("GARDES_DB_PATH", os.path.join(BASE_DIR, "gardes.db"))
BACKUP_DIR = os.path.join(BASE_DIR, "backups")

DEFAULT_ADMIN_USER = "admin"
DEFAULT_ADMIN_PASSWORD = "admin"

# --------------------------------------------------------------------------- #
#  Migrations
# --------------------------------------------------------------------------- #
# Chaque migration est un script SQL exécuté dans une transaction.
# Ne JAMAIS modifier une migration déjà publiée : en ajouter une nouvelle.
MIGRATIONS = [
    # ---- Version 1 : schéma initial --------------------------------------- #
    """
    CREATE TABLE admin (
        id            INTEGER PRIMARY KEY CHECK (id = 1),
        username      TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        must_change   INTEGER NOT NULL DEFAULT 0 CHECK (must_change IN (0, 1)),
        updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE categories (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        name        TEXT NOT NULL COLLATE NOCASE UNIQUE,
        description TEXT,
        active      INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
        created_at  TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE workers (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name   TEXT NOT NULL,
        staff_type  TEXT NOT NULL CHECK (staff_type IN ('superior', 'daily')),
        category_id INTEGER REFERENCES categories(id) ON DELETE RESTRICT,
        active      INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
        created_at  TEXT NOT NULL DEFAULT (datetime('now')),
        -- Un agent journalier a obligatoirement une catégorie,
        -- un agent supérieur n'en a jamais.
        CHECK ((staff_type = 'daily'    AND category_id IS NOT NULL) OR
               (staff_type = 'superior' AND category_id IS NULL))
    );
    CREATE INDEX idx_workers_type_cat ON workers(staff_type, category_id, active);

    CREATE TABLE absences (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        worker_id  INTEGER NOT NULL REFERENCES workers(id) ON DELETE CASCADE,
        start_date TEXT NOT NULL,
        end_date   TEXT NOT NULL,
        reason     TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        CHECK (end_date >= start_date)
    );
    CREATE INDEX idx_absences_worker ON absences(worker_id, start_date, end_date);

    CREATE TABLE shifts (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        shift_date  TEXT NOT NULL,
        staff_type  TEXT NOT NULL CHECK (staff_type IN ('superior', 'daily')),
        category_id INTEGER REFERENCES categories(id) ON DELETE RESTRICT,
        -- NULL = garde non couverte (aucun agent disponible)
        worker_id   INTEGER REFERENCES workers(id) ON DELETE RESTRICT,
        observation TEXT,
        is_manual   INTEGER NOT NULL DEFAULT 0 CHECK (is_manual IN (0, 1)),
        created_at  TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
        CHECK ((staff_type = 'daily'    AND category_id IS NOT NULL) OR
               (staff_type = 'superior' AND category_id IS NULL))
    );
    -- Garantit l'absence de doublon : un seul créneau par date / type / catégorie.
    CREATE UNIQUE INDEX uq_shift_slot ON shifts(shift_date, staff_type, IFNULL(category_id, 0));
    CREATE INDEX idx_shifts_date   ON shifts(shift_date);
    CREATE INDEX idx_shifts_worker ON shifts(worker_id, shift_date);

    CREATE TABLE settings (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );
    """,
    # ---- Version 2 : journal des modifications d'affectations -------------- #
    """
    CREATE TABLE shift_log (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        shift_date  TEXT NOT NULL,
        staff_type  TEXT NOT NULL,
        category    TEXT,
        action      TEXT NOT NULL,
        old_worker  TEXT,
        new_worker  TEXT,
        details     TEXT,
        created_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );
    CREATE INDEX idx_shift_log_created ON shift_log(created_at);
    """,
]

LATEST_VERSION = len(MIGRATIONS)


def get_connection(path=None):
    """Ouvre une connexion SQLite avec clés étrangères activées."""
    conn = sqlite3.connect(path or DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _backup_before_migration(path, from_version):
    """Copie de sécurité de la base avant toute migration."""
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        return None
    os.makedirs(BACKUP_DIR, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = os.path.join(BACKUP_DIR, f"gardes_v{from_version}_{stamp}.bak")
    src = sqlite3.connect(path)
    dst = sqlite3.connect(target)
    try:
        src.backup(dst)  # copie cohérente même si la base est ouverte
    finally:
        dst.close()
        src.close()
    return target


def migrate(path=None):
    """Applique les migrations manquantes. Ne détruit jamais de données."""
    path = path or DB_PATH
    conn = get_connection(path)
    try:
        current = conn.execute("PRAGMA user_version").fetchone()[0]
        if current > LATEST_VERSION:
            raise RuntimeError(
                f"La base de données (version {current}) est plus récente que "
                f"l'application (version {LATEST_VERSION}). Mettez l'application à jour."
            )
        if current == LATEST_VERSION:
            return current
        if current > 0:
            _backup_before_migration(path, current)
        for version in range(current + 1, LATEST_VERSION + 1):
            script = (
                "BEGIN;\n" + MIGRATIONS[version - 1] +
                f"\nPRAGMA user_version = {version};\nCOMMIT;"
            )
            try:
                conn.executescript(script)
            except Exception:
                # En cas d'erreur la transaction est annulée : la base reste intacte.
                if conn.in_transaction:
                    conn.execute("ROLLBACK")
                raise
        return LATEST_VERSION
    finally:
        conn.close()


def ensure_defaults(path=None):
    """Crée l'administrateur par défaut, la clé secrète et les paramètres initiaux
    uniquement s'ils n'existent pas (aucune donnée existante n'est écrasée)."""
    conn = get_connection(path)
    try:
        with conn:
            if conn.execute("SELECT COUNT(*) FROM admin").fetchone()[0] == 0:
                conn.execute(
                    "INSERT INTO admin (id, username, password_hash, must_change) "
                    "VALUES (1, ?, ?, 1)",
                    (DEFAULT_ADMIN_USER, generate_password_hash(DEFAULT_ADMIN_PASSWORD)),
                )
            defaults = {
                "org_name": "Mon organisation",
                "secret_key": secrets.token_hex(32),
            }
            for key, value in defaults.items():
                conn.execute(
                    "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (key, value)
                )
    finally:
        conn.close()


def init_db(path=None):
    """Point d'entrée unique : migre puis crée les valeurs par défaut."""
    version = migrate(path)
    ensure_defaults(path)
    return version


# --------------------------------------------------------------------------- #
#  Aides diverses
# --------------------------------------------------------------------------- #
def get_setting(conn, key, default=""):
    row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(conn, key, value):
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )


def log_shift_change(conn, shift_date, staff_type, category, action,
                     old_worker=None, new_worker=None, details=None):
    """Ajoute une ligne au journal des modifications (historique d'audit)."""
    conn.execute(
        "INSERT INTO shift_log (shift_date, staff_type, category, action, "
        "old_worker, new_worker, details) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (shift_date, staff_type, category, action, old_worker, new_worker, details),
    )


if __name__ == "__main__":
    print("Version du schéma :", init_db())
