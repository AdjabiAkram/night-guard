"""
Tests de bout en bout de l'application web (client de test Flask, base temporaire).
Lancer :  python -m unittest discover -s tests -v
"""
import io
import os
import sys
import tempfile
import unittest
from datetime import date, timedelta

_tmp = tempfile.TemporaryDirectory()
os.environ["GARDES_DB_PATH"] = os.path.join(_tmp.name, "e2e.db")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import app as app_module  # noqa: E402
import database  # noqa: E402


class WebTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = app_module.app
        cls.app.testing = True
        cls.c = cls.app.test_client()
        cls.start = date.today() + timedelta(days=1)

    @classmethod
    def tearDownClass(cls):
        _tmp.cleanup()

    # -- aides ------------------------------------------------------------- #
    def token(self):
        self.c.get("/login")
        with self.c.session_transaction() as s:
            return s["_csrf"]

    def post(self, url, data=None, follow=True):
        data = dict(data or {})
        data["csrf_token"] = self.token()
        return self.c.post(url, data=data, follow_redirects=follow)

    def login(self, user="admin", pwd="admin"):
        return self.post("/login", {"username": user, "password": pwd})

    def db(self):
        return database.get_connection()

    # -- scénario ordonné (test_01, test_02, ...) --------------------------- #
    def test_01_protection_and_login(self):
        r = self.c.get("/", follow_redirects=False)
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])
        for url in ("/personnel", "/planning", "/export/pdf", "/api/shift/1/candidates"):
            self.assertIn(self.c.get(url).status_code, (302, 401))
        # POST sans jeton CSRF refusé
        self.assertEqual(self.c.post("/login", data={"username": "admin", "password": "admin"}).status_code, 400)
        bad = self.login("admin", "mauvais")
        self.assertIn("incorrect", bad.get_data(as_text=True))
        ok = self.login()
        self.assertIn("Tableau de bord", ok.get_data(as_text=True))

    def test_02_default_password_must_change(self):
        self.login()
        html = self.c.get("/").get_data(as_text=True)
        self.assertIn("mot de passe par défaut", html)

    def test_03_categories_and_workers(self):
        self.login()
        for name in ("A", "B", "C"):
            self.post("/categories/save", {"name": name, "active": "1"})
        self.post("/categories/save", {"name": "a", "active": "1"})  # doublon (insensible à la casse)
        with self.db() as d:
            self.assertEqual(d.execute("SELECT COUNT(*) FROM categories").fetchone()[0], 3)
            cats = {r["name"]: r["id"] for r in d.execute("SELECT id, name FROM categories")}
        for cat, names in (("A", ("A1", "A2", "A3")), ("B", ("B1", "B2")), ("C", ("C1", "C2", "C3"))):
            for n in names:
                self.post("/personnel/save", {"full_name": n, "staff_type": "daily",
                                              "category_id": cats[cat], "active": "1"})
        for n in ("Sup1", "Sup2", "Sup3"):
            self.post("/personnel/save", {"full_name": n, "staff_type": "superior", "active": "1"})
        # Agent journalier sans catégorie : refusé
        r = self.post("/personnel/save", {"full_name": "Sans cat", "staff_type": "daily", "active": "1"})
        self.assertIn("Catégorie", r.get_data(as_text=True))
        with self.db() as d:
            self.assertEqual(d.execute("SELECT COUNT(*) FROM workers").fetchone()[0], 11)
        self.assertEqual(self.c.get("/personnel").status_code, 200)
        self.assertEqual(self.c.get("/personnel?type=daily&q=A1").status_code, 200)
        self.assertEqual(self.c.get("/categories").status_code, 200)

    def test_04_generate_and_view(self):
        self.login()
        end = self.start + timedelta(days=20)
        r = self.post("/planning/generate", {"start": self.start.isoformat(), "end": end.isoformat(),
                                             "do_daily": "1", "do_superior": "1", "keep_manual": "1"})
        self.assertIn("garde(s) créée(s)", r.get_data(as_text=True))
        with self.db() as d:
            self.assertEqual(d.execute("SELECT COUNT(*) FROM shifts WHERE staff_type='daily'").fetchone()[0], 63)
            self.assertEqual(d.execute("SELECT COUNT(*) FROM shifts WHERE staff_type='superior'").fetchone()[0], 21)
        page = self.c.get(f"/planning?start={self.start}&end={end}").get_data(as_text=True)
        self.assertIn("Personnel journalier", page)
        self.assertIn("Semaine du", page)
        for url in ("/", "/history", "/history?view=log", "/absences", "/settings"):
            self.assertEqual(self.c.get(url).status_code, 200, url)

    def test_05_absence_flow_and_candidates(self):
        self.login()
        with self.db() as d:
            sh = d.execute("SELECT s.id, s.shift_date, s.worker_id FROM shifts s WHERE s.category_id="
                           "(SELECT id FROM categories WHERE name='A') ORDER BY s.shift_date LIMIT 1").fetchone()
            other = d.execute("SELECT id FROM workers WHERE category_id=(SELECT id FROM categories "
                              "WHERE name='A') AND id<>?", (sh["worker_id"],)).fetchall()
        # Absence d'un autre agent de la catégorie le jour de la garde
        absent = other[0]["id"]
        r = self.post("/absences/save", {"worker_id": absent, "start_date": sh["shift_date"],
                                         "end_date": sh["shift_date"], "reason": "Congé"})
        self.assertIn("Absence enregistrée", r.get_data(as_text=True))
        # Dates incohérentes refusées
        r = self.post("/absences/save", {"worker_id": absent, "start_date": "2026-05-10", "end_date": "2026-05-01"})
        self.assertIn("date de fin", r.get_data(as_text=True))
        cand = self.c.get(f"/api/shift/{sh['id']}/candidates").get_json()["candidates"]
        self.assertNotIn(absent, [c["id"] for c in cand])
        # Remplacement par un agent absent refusé
        r = self.post(f"/planning/shift/{sh['id']}/update", {"worker_id": absent})
        self.assertIn("pas compatible", r.get_data(as_text=True))
        # Remplacement valide + observation
        target = cand[0]["id"] if cand else None
        if target:
            r = self.post(f"/planning/shift/{sh['id']}/update",
                          {"worker_id": target, "observation": "Échange validé"})
            self.assertIn("Agent remplacé", r.get_data(as_text=True))
        with self.db() as d:
            row = d.execute("SELECT worker_id, observation, is_manual FROM shifts WHERE id=?", (sh["id"],)).fetchone()
            self.assertEqual(row["observation"], "Échange validé" if target else None)
            self.assertEqual(row["worker_id"], target or sh["worker_id"])
            self.assertGreaterEqual(d.execute("SELECT COUNT(*) FROM shift_log").fetchone()[0], 2)

    def test_06_regeneration_keeps_other_periods(self):
        self.login()
        with self.db() as d:
            before = d.execute("SELECT COUNT(*) FROM shifts WHERE shift_date > ?",
                               ((self.start + timedelta(days=9)).isoformat(),)).fetchone()[0]
        self.post("/planning/generate", {"start": self.start.isoformat(),
                                         "end": (self.start + timedelta(days=9)).isoformat(),
                                         "do_daily": "1", "do_superior": "1", "keep_manual": "1"})
        with self.db() as d:
            after = d.execute("SELECT COUNT(*) FROM shifts WHERE shift_date > ?",
                              ((self.start + timedelta(days=9)).isoformat(),)).fetchone()[0]
            self.assertEqual(before, after)
            # Aucune absence ni doublon : un seul agent par date / catégorie
            dup = d.execute("SELECT COUNT(*) FROM (SELECT 1 FROM shifts GROUP BY shift_date, staff_type, "
                            "IFNULL(category_id,0) HAVING COUNT(*)>1)").fetchone()[0]
            self.assertEqual(dup, 0)

    def test_07_exports(self):
        self.login()
        end = self.start + timedelta(days=20)
        x = self.c.get(f"/export/xlsx?start={self.start}&end={end}")
        self.assertEqual(x.status_code, 200)
        self.assertEqual(x.data[:2], b"PK")
        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(x.data))
        self.assertEqual(wb.sheetnames, ["Personnel journalier", "Personnel supérieur"])
        self.assertEqual(wb["Personnel journalier"].max_row, 6 + 63)
        p = self.c.get(f"/export/pdf?start={self.start}&end={end}")
        self.assertEqual(p.status_code, 200)
        self.assertEqual(p.data[:4], b"%PDF")
        self.assertEqual(self.c.get("/export/csv").status_code, 404)

    def test_08_delete_rules(self):
        self.login()
        with self.db() as d:
            wid = d.execute("SELECT worker_id FROM shifts WHERE worker_id IS NOT NULL LIMIT 1").fetchone()[0]
            cid = d.execute("SELECT id FROM categories WHERE name='A'").fetchone()[0]
        r = self.post(f"/personnel/{wid}/delete")
        self.assertIn("historique", r.get_data(as_text=True))
        r = self.post(f"/categories/{cid}/delete")
        self.assertIn("suppression impossible", r.get_data(as_text=True))
        # Un agent sans historique peut être supprimé
        self.post("/personnel/save", {"full_name": "Temp", "staff_type": "superior", "active": "1"})
        with self.db() as d:
            tid = d.execute("SELECT id FROM workers WHERE full_name='Temp'").fetchone()[0]
        self.post(f"/personnel/{tid}/delete")
        with self.db() as d:
            self.assertIsNone(d.execute("SELECT 1 FROM workers WHERE id=?", (tid,)).fetchone())

    def test_09_security_misc(self):
        self.login()
        self.assertEqual(self.c.get("/inexistante").status_code, 404)
        # Injection SQL dans la recherche : traitée comme du texte
        self.assertEqual(self.c.get("/personnel?q=%27%3B+DROP+TABLE+workers%3B--").status_code, 200)
        self.assertEqual(self.c.get("/history?worker=1;DROP").status_code, 200)
        with self.db() as d:
            self.assertGreater(d.execute("SELECT COUNT(*) FROM workers").fetchone()[0], 0)
        # Redirection externe refusée
        r = self.post("/planning/shift/1/update", {"observation": "x", "return_url": "//evil.example"},
                      follow=False)
        self.assertNotIn("evil", r.headers.get("Location", ""))
        h = self.c.get("/").headers
        self.assertEqual(h["X-Frame-Options"], "DENY")
        self.assertIn("default-src 'self'", h["Content-Security-Policy"])

    def test_10_credentials_change_and_logout(self):
        self.login()
        r = self.post("/settings/credentials", {"username": "chef", "current_password": "admin",
                                                "new_password": "admin", "confirm_password": "admin"})
        self.assertIn("au moins 8 caractères", r.get_data(as_text=True))
        r = self.post("/settings/credentials", {"username": "chef", "current_password": "admin",
                                                "new_password": "password", "confirm_password": "password"})
        self.assertIn("trop faible", r.get_data(as_text=True))
        r = self.post("/settings/credentials", {"username": "chef", "current_password": "faux",
                                                "new_password": "MotDePasse!42", "confirm_password": "MotDePasse!42"})
        self.assertIn("incorrect", r.get_data(as_text=True))
        r = self.post("/settings/credentials", {"username": "chef", "current_password": "admin",
                                                "new_password": "MotDePasse!42", "confirm_password": "MotDePasse!42"})
        self.assertIn("Identifiants mis à jour", r.get_data(as_text=True))
        with self.db() as d:
            row = d.execute("SELECT username, password_hash, must_change FROM admin").fetchone()
            self.assertEqual(row["username"], "chef")
            self.assertNotIn("MotDePasse", row["password_hash"])  # stocké sous forme de hash
            self.assertEqual(row["must_change"], 0)
        self.post("/logout")
        self.assertEqual(self.c.get("/").status_code, 302)
        self.assertIn("Tableau de bord", self.login("chef", "MotDePasse!42").get_data(as_text=True))
        # Sauvegarde téléchargeable
        b = self.post("/settings/backup", follow=False)
        self.assertEqual(b.status_code, 200)
        self.assertEqual(b.data[:15], b"SQLite format 3")


if __name__ == "__main__":
    unittest.main()
