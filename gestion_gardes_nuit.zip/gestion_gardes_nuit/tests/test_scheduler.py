"""
Tests du moteur de planification.
Lancer :  python -m unittest discover -s tests -v   (depuis le dossier du projet)
"""
import os
import sys
import tempfile
import unittest
from datetime import date, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import database  # noqa: E402
import scheduler  # noqa: E402
from scheduler import assign_daily, assign_superior, daterange, week_start  # noqa: E402

D = date(2026, 1, 5)  # un lundi


def days(n, start=D):
    return [start + timedelta(days=i) for i in range(n)]


class PureAlgorithmTests(unittest.TestCase):
    def test_round_robin_and_no_consecutive(self):
        res = assign_daily([1, 2, 3], days(9), {})
        seq = [res[d] for d in days(9)]
        self.assertEqual(seq, [1, 2, 3, 1, 2, 3, 1, 2, 3])
        self.assertTrue(all(a != b for a, b in zip(seq, seq[1:])))

    def test_fair_distribution(self):
        res = assign_daily([1, 2, 3, 4], days(100), {})
        counts = {w: list(res.values()).count(w) for w in (1, 2, 3, 4)}
        self.assertLessEqual(max(counts.values()) - min(counts.values()), 1)

    def test_absent_never_assigned_and_returns(self):
        # Agent 2 absent du 7 au 12 janvier inclus.
        absences = {2: [(date(2026, 1, 7), date(2026, 1, 12))]}
        res = assign_daily([1, 2, 3], days(21), absences)
        for d, w in res.items():
            if date(2026, 1, 7) <= d <= date(2026, 1, 12):
                self.assertNotEqual(w, 2, f"agent absent affecté le {d}")
        # Dès la fin de l'absence il redevient éligible (et prioritaire).
        self.assertEqual(res[date(2026, 1, 13)], 2)

    def test_uncovered_when_nobody_available(self):
        absences = {1: [(D, D + timedelta(days=2))]}
        res = assign_daily([1], days(5), absences)
        self.assertIsNone(res[D])
        self.assertIsNone(res[D + timedelta(days=2)])
        self.assertEqual(res[D + timedelta(days=3)], 1)

    def test_single_worker_consecutive_allowed_when_unavoidable(self):
        res = assign_daily([7], days(3), {})
        self.assertEqual(list(res.values()), [7, 7, 7])

    def test_continues_after_history(self):
        last = {1: D - timedelta(days=3), 2: D - timedelta(days=2), 3: D - timedelta(days=1)}
        res = assign_daily([1, 2, 3], days(3), {}, last_assigned=last,
                           counts={1: 5, 2: 5, 3: 5}, previous_worker=3)
        self.assertEqual([res[d] for d in days(3)], [1, 2, 3])

    def test_locked_days_are_kept_and_counted(self):
        res = assign_daily([1, 2, 3], days(4), {}, locked={D + timedelta(days=1): 1})
        self.assertNotIn(D + timedelta(days=1), res)
        self.assertEqual(res[D], 1)
        self.assertNotEqual(res[D + timedelta(days=2)], 1)

    def test_superior_same_worker_all_week(self):
        ds = days(14)
        weeks = []
        for ws in (D, D + timedelta(days=7)):
            weeks.append({"start": ws, "full": [ws + timedelta(days=i) for i in range(7)],
                          "planned": [ws + timedelta(days=i) for i in range(7)],
                          "fixed": None, "locked_worker": None})
        res, warn = assign_superior([1, 2, 3], weeks, {})
        self.assertEqual({res[d] for d in ds[:7]}, {1})
        self.assertEqual({res[d] for d in ds[7:]}, {2})
        self.assertEqual(warn, [])

    def test_superior_skips_agent_absent_during_week(self):
        ws = D
        weeks = [{"start": ws, "full": [ws + timedelta(days=i) for i in range(7)],
                  "planned": [ws + timedelta(days=i) for i in range(7)],
                  "fixed": None, "locked_worker": None}]
        absences = {1: [(D + timedelta(days=4), D + timedelta(days=4))]}  # absent vendredi
        res, _ = assign_superior([1, 2], weeks, absences)
        self.assertEqual({res[d] for d in days(7)}, {2})


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.tmp.name, "test.db")
        database.init_db(self.path)
        self.conn = database.get_connection(self.path)
        c = self.conn
        with c:
            c.execute("INSERT INTO categories (name) VALUES ('A'), ('B'), ('C')")
            for cat, names in ((1, ("A1", "A2", "A3")), (2, ("B1", "B2")), (3, ("C1", "C2", "C3", "C4"))):
                for n in names:
                    c.execute("INSERT INTO workers (full_name, staff_type, category_id) "
                              "VALUES (?, 'daily', ?)", (n, cat))
            for n in ("S1", "S2", "S3"):
                c.execute("INSERT INTO workers (full_name, staff_type) VALUES (?, 'superior')", (n,))

    def tearDown(self):
        self.conn.close()
        self.tmp.cleanup()

    def count(self, where="1=1", params=()):
        return self.conn.execute(f"SELECT COUNT(*) FROM shifts WHERE {where}", params).fetchone()[0]

    def test_one_agent_per_category_per_night(self):
        scheduler.generate_planning(self.conn, D, D + timedelta(days=29))
        # 30 nuits x 3 catégories + 30 jours supérieurs
        self.assertEqual(self.count("staff_type='daily'"), 90)
        dup = self.conn.execute(
            "SELECT COUNT(*) FROM (SELECT shift_date, category_id FROM shifts WHERE staff_type='daily' "
            "GROUP BY shift_date, category_id HAVING COUNT(*) > 1)").fetchone()[0]
        self.assertEqual(dup, 0)

    def test_rotation_continues_between_generations(self):
        scheduler.generate_planning(self.conn, D, D + timedelta(days=3))
        scheduler.generate_planning(self.conn, D + timedelta(days=4), D + timedelta(days=9))
        rows = self.conn.execute(
            "SELECT worker_id FROM shifts WHERE staff_type='daily' AND category_id=1 "
            "ORDER BY shift_date").fetchall()
        seq = [r[0] for r in rows]
        self.assertEqual(seq, [1, 2, 3, 1, 2, 3, 1, 2, 3, 1])  # pas de redémarrage à zéro

    def test_regeneration_never_touches_outside_period(self):
        scheduler.generate_planning(self.conn, D, D + timedelta(days=29))
        before = self.conn.execute(
            "SELECT shift_date, staff_type, category_id, worker_id FROM shifts "
            "WHERE shift_date < ? OR shift_date > ? ORDER BY 1,2,3",
            ((D + timedelta(days=9)).isoformat(), (D + timedelta(days=19)).isoformat())).fetchall()
        scheduler.generate_planning(self.conn, D + timedelta(days=9), D + timedelta(days=19))
        after = self.conn.execute(
            "SELECT shift_date, staff_type, category_id, worker_id FROM shifts "
            "WHERE shift_date < ? OR shift_date > ? ORDER BY 1,2,3",
            ((D + timedelta(days=9)).isoformat(), (D + timedelta(days=19)).isoformat())).fetchall()
        self.assertEqual([tuple(r) for r in before], [tuple(r) for r in after])
        self.assertEqual(self.count("staff_type='daily'"), 90)

    def test_absence_respected_and_uncovered_reported(self):
        with self.conn:
            # B1 et B2 absents le 8 janvier -> catégorie B non couverte ce soir-là
            for wid in (4, 5):
                self.conn.execute("INSERT INTO absences (worker_id, start_date, end_date) "
                                  "VALUES (?, '2026-01-08', '2026-01-08')", (wid,))
        rep = scheduler.generate_planning(self.conn, D, D + timedelta(days=6))
        self.assertEqual(len(rep.uncovered), 1)
        self.assertEqual(rep.uncovered[0]["date"], date(2026, 1, 8))
        self.assertEqual(self.count("worker_id IS NULL"), 1)

    def test_superior_one_per_week_and_equitable(self):
        scheduler.generate_planning(self.conn, D, D + timedelta(days=7 * 12 - 1))
        weeks = self.conn.execute(
            "SELECT worker_id, COUNT(DISTINCT date(shift_date,'weekday 0','-6 days')) n "
            "FROM shifts WHERE staff_type='superior' GROUP BY worker_id").fetchall()
        self.assertEqual({r["n"] for r in weeks}, {4})
        # Un seul agent par semaine
        bad = self.conn.execute(
            "SELECT COUNT(*) FROM (SELECT date(shift_date,'weekday 0','-6 days') w FROM shifts "
            "WHERE staff_type='superior' GROUP BY w HAVING COUNT(DISTINCT worker_id) > 1)").fetchone()[0]
        self.assertEqual(bad, 0)

    def test_partial_week_keeps_same_superior(self):
        # Première génération jusqu'au mercredi, la seconde complète la semaine.
        scheduler.generate_planning(self.conn, D, D + timedelta(days=2), do_daily=False)
        scheduler.generate_planning(self.conn, D + timedelta(days=3), D + timedelta(days=6),
                                    do_daily=False)
        ws = self.conn.execute("SELECT DISTINCT worker_id FROM shifts WHERE staff_type='superior'"
                               ).fetchall()
        self.assertEqual(len(ws), 1)

    def test_manual_assignment_kept_on_regeneration(self):
        scheduler.generate_planning(self.conn, D, D + timedelta(days=6), do_superior=False)
        shift = self.conn.execute("SELECT id FROM shifts WHERE category_id=1 AND shift_date=?",
                                  ((D + timedelta(days=2)).isoformat(),)).fetchone()
        cands = scheduler.get_candidates(self.conn, shift["id"])
        scheduler.apply_shift_update(self.conn, shift["id"], cands[0]["id"], "Échange")
        scheduler.generate_planning(self.conn, D, D + timedelta(days=6), do_superior=False)
        row = self.conn.execute("SELECT worker_id, observation FROM shifts WHERE id IS NOT NULL "
                                "AND category_id=1 AND shift_date=?",
                                ((D + timedelta(days=2)).isoformat(),)).fetchone()
        self.assertEqual(row["worker_id"], cands[0]["id"])
        self.assertEqual(row["observation"], "Échange")

    def test_replacement_refuses_absent_or_incompatible(self):
        scheduler.generate_planning(self.conn, D, D + timedelta(days=2), do_superior=False)
        shift = self.conn.execute("SELECT id, worker_id FROM shifts WHERE category_id=1 "
                                  "AND shift_date=?", (D.isoformat(),)).fetchone()
        with self.conn:
            self.conn.execute("INSERT INTO absences (worker_id, start_date, end_date) "
                              "VALUES (3, ?, ?)", (D.isoformat(), D.isoformat()))
        ids = {c["id"] for c in scheduler.get_candidates(self.conn, shift["id"])}
        self.assertNotIn(3, ids)          # absent
        self.assertNotIn(4, ids)          # autre catégorie
        self.assertNotIn(shift["worker_id"], ids)
        with self.assertRaises(scheduler.ScheduleError):
            scheduler.apply_shift_update(self.conn, shift["id"], 4)

    def test_migration_preserves_data(self):
        scheduler.generate_planning(self.conn, D, D + timedelta(days=2))
        n = self.count()
        self.conn.close()
        self.assertEqual(database.init_db(self.path), database.LATEST_VERSION)  # ré-exécution
        self.conn = database.get_connection(self.path)
        self.assertEqual(self.count(), n)


if __name__ == "__main__":
    unittest.main()
