/* Gestion des Gardes de Nuit - comportements côté navigateur (aucune dépendance externe). */
(function () {
  'use strict';

  /* ---- Confirmation avant les actions sensibles (formulaires data-confirm) ---- */
  document.addEventListener('submit', function (e) {
    var msg = e.target.dataset ? e.target.dataset.confirm : null;
    if (msg && !window.confirm(msg)) { e.preventDefault(); }
  });

  /* ---- Impression ---- */
  document.addEventListener('click', function (e) {
    if (e.target.closest && e.target.closest('[data-print]')) { window.print(); }
  });

  /* ---- Masquer automatiquement les messages de succès ---- */
  setTimeout(function () {
    document.querySelectorAll('.alert-success.show').forEach(function (a) {
      if (window.bootstrap) { bootstrap.Alert.getOrCreateInstance(a).close(); }
    });
  }, 6000);

  /* ---- Date de fin >= date de début ---- */
  function bindDateRange(form) {
    var start = form.querySelector('input[name="start"], input[name="start_date"]');
    var end = form.querySelector('input[name="end"], input[name="end_date"]');
    if (!start || !end) { return; }
    function sync() {
      end.min = start.value || '';
      if (start.value && end.value && end.value < start.value) { end.value = start.value; }
    }
    start.addEventListener('change', sync);
    sync();
    form._syncRange = sync;
  }
  document.querySelectorAll('form[data-date-range]').forEach(bindDateRange);

  /* ---- Catégorie obligatoire seulement pour le personnel journalier ---- */
  function toggleCategory(form) {
    var type = form.querySelector('[data-toggle-category]');
    var wrap = form.querySelector('[data-category-wrap]');
    if (!type || !wrap) { return; }
    var select = wrap.querySelector('select');
    var daily = type.value === 'daily';
    wrap.classList.toggle('d-none', !daily);
    select.required = daily;
    if (!daily) { select.value = ''; }
  }
  document.querySelectorAll('[data-toggle-category]').forEach(function (el) {
    el.addEventListener('change', function () { toggleCategory(el.form); });
  });

  /* ---- Modales d'ajout / modification : remplissage depuis les attributs data-* ---- */
  document.querySelectorAll('.modal').forEach(function (modal) {
    var form = modal.querySelector('form[data-modal-form]');
    if (!form) { return; }
    modal.addEventListener('show.bs.modal', function (ev) {
      var data = ev.relatedTarget ? ev.relatedTarget.dataset : {};
      form.reset();
      form.querySelectorAll('[name]').forEach(function (el) {
        if (el.name === 'csrf_token' || !(el.name in data)) { return; }
        if (el.type === 'checkbox') { el.checked = data[el.name] === '1'; }
        else { el.value = data[el.name]; }
      });
      var title = modal.querySelector('.modal-title');
      if (title && data.modalTitle) { title.textContent = data.modalTitle; }
      toggleCategory(form);
      if (form._syncRange) { form._syncRange(); }
    });
    modal.addEventListener('shown.bs.modal', function () {
      var first = form.querySelector('input:not([type=hidden]), select');
      if (first) { first.focus(); }
    });
  });

  /* ---- Modale « Modifier la garde » : liste des remplaçants compatibles ---- */
  var shiftModal = document.getElementById('shiftModal');
  if (shiftModal) {
    var form = document.getElementById('shiftForm');
    var select = document.getElementById('shiftWorkerSelect');
    var help = document.getElementById('shiftHelp');
    var wholeWeek = document.getElementById('wholeWeek');
    var wholeWrap = document.getElementById('wholeWeekWrap');
    var currentId = null;
    var requestToken = 0;

    function loadCandidates() {
      var token = ++requestToken;
      select.innerHTML = '';
      var keep = document.createElement('option');
      keep.value = '';
      keep.textContent = '— Conserver l\u2019agent actuel —';
      select.appendChild(keep);
      help.textContent = 'Chargement\u2026';
      var url = form.dataset.candidatesTemplate.replace('/0/', '/' + currentId + '/') +
                (wholeWeek.checked ? '?whole_week=1' : '');
      fetch(url, { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
        .then(function (r) { if (!r.ok) { throw new Error('http'); } return r.json(); })
        .then(function (data) {
          if (token !== requestToken) { return; }
          data.candidates.forEach(function (c) {
            var o = document.createElement('option');
            o.value = c.id;
            o.textContent = c.name + (c.warning ? '  \u26A0 ' + c.warning : '');
            select.appendChild(o);
          });
          help.textContent = data.candidates.length
            ? data.candidates.length + ' agent(s) disponible(s).'
            : 'Aucun autre agent compatible et disponible \u00e0 cette date.';
        })
        .catch(function () {
          if (token === requestToken) { help.textContent = 'Impossible de charger la liste des agents.'; }
        });
    }

    shiftModal.addEventListener('show.bs.modal', function (ev) {
      var d = ev.relatedTarget.dataset;
      currentId = d.shiftId;
      form.action = form.dataset.actionTemplate.replace('/0/', '/' + currentId + '/');
      document.getElementById('shiftDate').textContent = d.date;
      document.getElementById('shiftLabel').textContent = d.label;
      document.getElementById('shiftWorker').textContent = d.worker || 'Non couverte';
      document.getElementById('shiftObs').value = d.observation || '';
      var superior = d.staffType === 'superior';
      wholeWrap.classList.toggle('d-none', !superior);
      wholeWeek.checked = !!d.wholeWeek;
      loadCandidates();
    });
    wholeWeek.addEventListener('change', loadCandidates);
  }
})();
