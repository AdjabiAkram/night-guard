"""
exports.py - Exportation des plannings au format Excel (OpenPyXL) et PDF (ReportLab).

Contenu des documents : nom de l'organisation, période, date d'édition, date et jour
de la semaine, type de personnel, catégorie (journalier), agent affecté, observations.
Mise en page prévue pour l'impression (A4, en-têtes répétés, numéros de page).
"""
import io
from datetime import datetime
from xml.sax.saxutils import escape

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from scheduler import format_date_fr, parse_date, weekday_fr

UNCOVERED = "NON COUVERTE"
DAILY_LABEL = "Personnel journalier"
SUPERIOR_LABEL = "Personnel supérieur"


def fetch_rows(conn, start, end):
    """Retourne (gardes journalières, gardes supérieures) sur la période."""
    daily = conn.execute(
        "SELECT s.shift_date, c.name AS category, w.full_name AS worker, s.observation "
        "FROM shifts s JOIN categories c ON c.id = s.category_id "
        "LEFT JOIN workers w ON w.id = s.worker_id "
        "WHERE s.staff_type='daily' AND s.shift_date BETWEEN ? AND ? "
        "ORDER BY s.shift_date, c.name COLLATE NOCASE", (start, end)).fetchall()
    superior = conn.execute(
        "SELECT s.shift_date, w.full_name AS worker, s.observation FROM shifts s "
        "LEFT JOIN workers w ON w.id = s.worker_id "
        "WHERE s.staff_type='superior' AND s.shift_date BETWEEN ? AND ? "
        "ORDER BY s.shift_date", (start, end)).fetchall()
    return daily, superior


def _period_text(start, end):
    return (f"Période : du {format_date_fr(start, False)} "
            f"au {format_date_fr(end, False)}")


def _edition_text():
    return "Édité le " + datetime.now().strftime("%d/%m/%Y à %H:%M")


# --------------------------------------------------------------------------- #
#  Excel
# --------------------------------------------------------------------------- #
def build_xlsx(conn, org_name, start, end):
    daily, superior = fetch_rows(conn, start, end)
    wb = Workbook()
    ws1 = wb.active
    ws1.title = "Personnel journalier"
    _fill_sheet(
        ws1, org_name, "Planning des gardes de nuit - " + DAILY_LABEL, start, end,
        ["Date", "Jour", "Type de personnel", "Catégorie", "Agent affecté", "Observations"],
        [[parse_date(r["shift_date"]), weekday_fr(r["shift_date"]).capitalize(), DAILY_LABEL,
          r["category"], r["worker"] or UNCOVERED, r["observation"] or ""] for r in daily],
        [14, 13, 22, 22, 32, 45], uncovered_col=4)
    ws2 = wb.create_sheet("Personnel supérieur")
    _fill_sheet(
        ws2, org_name, "Planning des gardes de nuit - " + SUPERIOR_LABEL, start, end,
        ["Date", "Jour", "Type de personnel", "Agent affecté", "Observations"],
        [[parse_date(r["shift_date"]), weekday_fr(r["shift_date"]).capitalize(), SUPERIOR_LABEL,
          r["worker"] or UNCOVERED, r["observation"] or ""] for r in superior],
        [14, 13, 22, 32, 50], uncovered_col=3)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _fill_sheet(ws, org_name, title, start, end, headers, rows, widths, uncovered_col):
    thin = Side(style="thin", color="999999")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    ncols = len(headers)
    last = get_column_letter(ncols)

    ws["A1"] = org_name
    ws["A1"].font = Font(size=16, bold=True, color="1F3864")
    ws["A2"] = title
    ws["A2"].font = Font(size=13, bold=True)
    ws["A3"] = _period_text(start, end)
    ws["A4"] = _edition_text()
    ws["A4"].font = Font(italic=True, color="555555")
    for r in (1, 2, 3, 4):
        ws.merge_cells(f"A{r}:{last}{r}")

    header_row = 6
    for i, h in enumerate(headers, start=1):
        c = ws.cell(row=header_row, column=i, value=h)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1F3864")
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = border
    ws.row_dimensions[header_row].height = 22

    weekend = PatternFill("solid", fgColor="F2F2F2")
    red = PatternFill("solid", fgColor="F8D7DA")
    for n, row in enumerate(rows, start=header_row + 1):
        is_weekend = row[0].weekday() >= 5
        for i, value in enumerate(row, start=1):
            c = ws.cell(row=n, column=i, value=value)
            c.border = border
            c.alignment = Alignment(vertical="top", wrap_text=True)
            if i == 1:
                c.number_format = "DD/MM/YYYY"
                c.alignment = Alignment(horizontal="center", vertical="top")
            if is_weekend:
                c.fill = weekend
        cell = ws.cell(row=n, column=uncovered_col + 1)
        if cell.value == UNCOVERED:
            cell.fill = red
            cell.font = Font(bold=True, color="842029")
    if not rows:
        ws.cell(row=header_row + 1, column=1, value="Aucune garde sur cette période.")
        ws.merge_cells(start_row=header_row + 1, start_column=1,
                       end_row=header_row + 1, end_column=ncols)

    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = ws.cell(row=header_row + 1, column=1)

    # Mise en page d'impression
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_title_rows = f"{header_row}:{header_row}"
    ws.print_options.horizontalCentered = True
    ws.page_margins.left = ws.page_margins.right = 0.5
    ws.page_margins.top = ws.page_margins.bottom = 0.7
    ws.oddFooter.center.text = "Page &P / &N"
    ws.oddFooter.right.text = "&D"


# --------------------------------------------------------------------------- #
#  PDF
# --------------------------------------------------------------------------- #
class _NumberedCanvas(canvas.Canvas):
    """Canvas qui écrit « Page x / y » sur chaque page."""

    def __init__(self, *args, footer_left="", **kwargs):
        super().__init__(*args, **kwargs)
        self._pages = []
        self._footer_left = footer_left

    def showPage(self):
        self._pages.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total = len(self._pages)
        for state in self._pages:
            self.__dict__.update(state)
            w, _h = self._pagesize
            self.setFont("Helvetica", 8)
            self.setFillColor(colors.HexColor("#555555"))
            self.drawString(1.5 * cm, 1 * cm, self._footer_left)
            self.drawRightString(w - 1.5 * cm, 1 * cm, f"Page {self._pageNumber} / {total}")
            super().showPage()
        super().save()


def build_pdf(conn, org_name, start, end):
    daily, superior = fetch_rows(conn, start, end)
    buf = io.BytesIO()
    page = landscape(A4)
    doc = SimpleDocTemplate(buf, pagesize=page, leftMargin=1.5 * cm, rightMargin=1.5 * cm,
                            topMargin=1.5 * cm, bottomMargin=1.8 * cm,
                            title=f"Planning des gardes de nuit - {org_name}", author=org_name)
    styles = getSampleStyleSheet()
    h_org = ParagraphStyle("org", parent=styles["Title"], fontSize=18, alignment=0,
                           textColor=colors.HexColor("#1F3864"), spaceAfter=2)
    h_sub = ParagraphStyle("sub", parent=styles["Normal"], fontSize=11, spaceAfter=2)
    h_sec = ParagraphStyle("sec", parent=styles["Heading2"], fontSize=13, spaceBefore=10,
                           textColor=colors.HexColor("#1F3864"))
    cell = ParagraphStyle("cell", parent=styles["Normal"], fontSize=9, leading=11)
    cell_b = ParagraphStyle("cellb", parent=cell, fontName="Helvetica-Bold")
    head = ParagraphStyle("head", parent=cell, fontName="Helvetica-Bold", textColor=colors.white)

    def p(text, style=cell):
        return Paragraph(escape(str(text or "")), style)

    story = [
        Paragraph(escape(org_name), h_org),
        Paragraph("Planning des gardes de nuit", h_sub),
        Paragraph(escape(_period_text(start, end)), h_sub),
        Paragraph(escape(_edition_text()), ParagraphStyle("ed", parent=h_sub, fontSize=9,
                                                          textColor=colors.HexColor("#555555"))),
        Spacer(1, 6),
    ]

    def table(title, headers, data, widths, uncovered_idx):
        story.append(Paragraph(escape(title), h_sec))
        if not data:
            story.append(Paragraph("Aucune garde sur cette période.", cell))
            return
        rows = [[p(h, head) for h in headers]]
        style = [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F3864")),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#999999")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]
        for i, (d, values) in enumerate(data, start=1):
            row = []
            for j, v in enumerate(values):
                if j == uncovered_idx and v == UNCOVERED:
                    row.append(Paragraph(f'<font color="#842029"><b>{UNCOVERED}</b></font>', cell))
                    style.append(("BACKGROUND", (j, i), (j, i), colors.HexColor("#F8D7DA")))
                else:
                    row.append(p(v))
            rows.append(row)
            if parse_date(d).weekday() >= 5:
                style.append(("BACKGROUND", (0, i), (-1, i), colors.HexColor("#F2F2F2")))
                if values[uncovered_idx] == UNCOVERED:
                    style.append(("BACKGROUND", (uncovered_idx, i), (uncovered_idx, i),
                                  colors.HexColor("#F8D7DA")))
        t = Table(rows, colWidths=widths, repeatRows=1)
        t.setStyle(TableStyle(style))
        story.append(t)

    usable = page[0] - 3 * cm
    table(f"{DAILY_LABEL}",
          ["Date", "Jour", "Catégorie", "Agent affecté", "Observations"],
          [(r["shift_date"], [format_date_fr(r["shift_date"], False), weekday_fr(r["shift_date"]).capitalize(),
                              r["category"], r["worker"] or UNCOVERED, r["observation"] or ""])
           for r in daily],
          [3.4 * cm, 2.6 * cm, 4.5 * cm, 6.5 * cm, usable - 17 * cm], 3)
    table(f"{SUPERIOR_LABEL}",
          ["Date", "Jour", "Type de personnel", "Agent affecté", "Observations"],
          [(r["shift_date"], [format_date_fr(r["shift_date"], False), weekday_fr(r["shift_date"]).capitalize(),
                              SUPERIOR_LABEL, r["worker"] or UNCOVERED, r["observation"] or ""])
           for r in superior],
          [3.4 * cm, 2.6 * cm, 4.5 * cm, 6.5 * cm, usable - 17 * cm], 3)

    footer = f"{org_name} - Gardes de nuit"
    doc.build(story, canvasmaker=lambda *a, **k: _NumberedCanvas(*a, footer_left=footer, **k))
    return buf.getvalue()
