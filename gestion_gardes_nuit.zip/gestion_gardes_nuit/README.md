# 🌙 Gestion des Gardes de Nuit

Application web **locale** (Flask + SQLite + Bootstrap 5) pour automatiser la planification des gardes
nocturnes : personnel journalier (un agent par catégorie et par nuit) et personnel supérieur
(un agent par semaine). Interface en français, responsive, fonctionnement hors ligne.

- Adresse : <http://127.0.0.1:5000> (accessible **uniquement** depuis votre PC)
- Compatible Windows 10 / 11 (fonctionne aussi sous Linux et macOS)

---

## 1. Installation (Windows)

1. Installez **Python 3.9 ou plus récent** depuis <https://www.python.org/downloads/>
   (cochez **« Add python.exe to PATH »** pendant l'installation).
2. Copiez le dossier `gestion_gardes_nuit` où vous voulez (ex. `C:\GestionGardes`).
3. **Double-cliquez sur `run.bat`.**
   - Au premier lancement, le script crée un environnement virtuel `venv` et installe les dépendances
     (Flask, OpenPyXL, ReportLab) : une connexion Internet est nécessaire **cette seule fois**.
   - Le navigateur s'ouvre automatiquement sur <http://127.0.0.1:5000>.
4. Connexion initiale : **`admin` / `admin`**. L'application vous demande de définir un nouveau mot de passe
   dans **Paramètres**.

Pour arrêter l'application : fermez la fenêtre noire (console) ou appuyez sur `Ctrl+C`.

### Lancement manuel (toutes plateformes)

```bash
python -m venv venv
venv\Scripts\activate          # Linux/macOS : source venv/bin/activate
pip install -r requirements.txt
python app.py
```

> Bootstrap 5 est **fourni dans `static/vendor/`** : aucune connexion Internet n'est requise pour utiliser l'application.

---

## 2. Prise en main (ordre conseillé)

1. **Paramètres** : changez le mot de passe et saisissez le **nom de l'organisation** (il apparaît dans les exports).
2. **Catégories** : créez les catégories du personnel journalier (ex. A, B, C).
3. **Personnel** : ajoutez les agents.
   - *Personnel journalier* : catégorie **obligatoire**.
   - *Personnel supérieur* : participe à la rotation hebdomadaire (lundi → dimanche).
4. **Absences** (facultatif) : saisissez les périodes d'indisponibilité (début, fin, motif).
5. **Planning** → **Générer le planning** : choisissez la date de début et de fin.
6. Consultez, corrigez manuellement, ajoutez des observations, puis **exportez** (Excel / PDF) ou **imprimez**.

### Pages

| Page | Rôle |
|---|---|
| Tableau de bord | Totaux, prochaines gardes, répartition par agent et statistiques d'équité, alertes (gardes non couvertes, agents absents/désactivés encore affectés) |
| Personnel | Ajout, modification, désactivation, suppression ; filtres par groupe, catégorie, statut |
| Catégories | Création, modification, désactivation, suppression |
| Absences | Liste complète, ajout, modification, suppression ; filtres |
| Planning | Génération, affichage séparé journalier / supérieur, remplacement, observations, exports, impression |
| Historique | Gardes passées filtrables (dates, type, catégorie, agent) + **journal des modifications** |
| Paramètres | Organisation, identifiants, sauvegarde de la base |

---

## 3. Règles de génération

**Personnel journalier** (rotation indépendante pour chaque catégorie *active*) — pour chaque nuit :

1. on ne retient que les agents **actifs** de la catégorie et **disponibles** (sans absence ce jour-là) ;
2. on évite l'agent de la nuit précédente (sauf s'il est le seul disponible) ;
3. on choisit l'agent dont la **dernière garde est la plus ancienne** (rotation « tourniquet »), puis, à égalité,
   celui qui a le moins de gardes, puis le plus ancien dans la liste.

Conséquences :
- la rotation **continue** à partir de l'historique : une nouvelle génération ne repart jamais de zéro ;
- un agent absent est ignoré ; à la fin de son absence il redevient **automatiquement prioritaire** ;
- si aucun agent n'est disponible dans une catégorie, la garde est créée **« Non couverte »** (en rouge, signalée
  à la génération, dans le planning et sur le tableau de bord).

**Personnel supérieur** — un seul agent par semaine (lundi → dimanche), qui garde la responsabilité de toute la
semaine. L'agent choisi est disponible pendant **toute la semaine** ; à défaut, pendant toute la partie planifiée ;
en dernier recours, la semaine est répartie jour par jour (avec avertissement) ou signalée non couverte.
Si une semaine est déjà partiellement planifiée (période commençant en milieu de semaine), le même agent la conserve.

**Génération sur une période** :
- seules les gardes **dans** la période sont remplacées, **jamais** celles situées en dehors ;
- l'option *« Conserver les affectations modifiées manuellement »* (cochée par défaut) protège vos corrections ;
- les observations saisies sont reportées sur les nouvelles gardes ;
- la génération est **atomique** (tout ou rien) ;
- un index unique en base interdit tout **doublon** (même date + même catégorie).

**Modification manuelle** : seuls les agents **du même groupe / de la même catégorie, actifs et disponibles** à la
date (ou sur toute la semaine pour le personnel supérieur) sont proposés. Un avertissement ⚠ signale un agent déjà de
garde la veille ou le lendemain. Chaque remplacement est inscrit dans le journal (Historique).

---

## 4. Données, migrations et sauvegardes

- Toutes les données sont dans **`gardes.db`** (créé automatiquement au premier lancement, à côté de `app.py`).
- **La base n'est jamais supprimée ni recréée** lors d'une mise à jour. Le schéma évolue par **migrations versionnées**
  (`PRAGMA user_version`, liste `MIGRATIONS` dans `database.py`). Avant toute migration sur une base existante,
  une copie est créée dans **`backups/`**.
- **Mettre à jour l'application** : remplacez les fichiers du programme (`*.py`, `templates/`, `static/`, …) **sans
  toucher à `gardes.db` ni à `backups/`** ; relancez `run.bat`.
- **Sauvegarde manuelle** : *Paramètres → Télécharger une sauvegarde*, ou copiez simplement `gardes.db`.
- **Restaurer** : arrêtez l'application et remplacez `gardes.db` par votre sauvegarde.
- Ajouter une évolution de schéma (développeurs) : ajoutez un **nouveau** script SQL à la fin de `MIGRATIONS`
  dans `database.py` ; ne modifiez jamais une migration déjà livrée.

Un agent ayant un **historique de gardes** ne peut pas être supprimé (l'historique doit rester intact) :
désactivez-le. Même règle pour les catégories contenant des agents ou des gardes.

---

## 5. Exports et impression

*Planning → Excel (.xlsx)* ou *PDF* pour la période affichée. Contenu : nom de l'organisation, période, date
d'édition, date et jour de la semaine, type de personnel, catégorie (journalier), agent affecté, observations,
gardes non couvertes en rouge. Mise en page A4 paysage, en-têtes répétés, numéros de page.
Le bouton **Imprimer** utilise une feuille de style d'impression dédiée (les deux plannings sont imprimés).

---

## 6. Sécurité

- Une seule interface d'administration, **protégée par connexion** : toutes les pages (y compris exports et API)
  exigent une session.
- Mot de passe stocké **haché** (Werkzeug, PBKDF2/scrypt) ; modification dans *Paramètres* (mot de passe actuel requis,
  8 caractères minimum). Limitation des tentatives de connexion (5 échecs → 1 minute de blocage).
- Jeton **CSRF** sur tous les formulaires, cookies de session `HttpOnly` / `SameSite=Lax`, en-têtes de sécurité (CSP, etc.).
- **Validation côté serveur** de toutes les saisies ; requêtes SQL **paramétrées** (aucune injection possible).
- Erreurs gérées proprement (pages d'erreur en français, journal dans la console).
- Le serveur écoute **uniquement sur 127.0.0.1**.

---

## 6 bis. Tests

```bash
python -m unittest discover -s tests -v
```

28 tests : rotation et continuité, équité, absences et retours, gardes non couvertes, absence de doublons,
régénération sans toucher aux autres périodes, remplacement manuel, migrations sans perte de données, authentification,
CSRF, exports Excel/PDF, règles de suppression.

---

## 7. Structure du projet

```
gestion_gardes_nuit/
├── app.py            # Application Flask : routes, validation, sécurité
├── database.py       # SQLite : schéma, migrations versionnées, valeurs par défaut
├── scheduler.py      # Moteur de génération (algorithmes purs + accès base) — aucun code d'interface
├── exports.py        # Exports Excel (OpenPyXL) et PDF (ReportLab)
├── requirements.txt
├── README.md
├── run.bat           # Lanceur Windows
├── templates/        # base, login, dashboard, personnel, categories, absences, planning, history, settings (+ error, _macros)
├── static/
│   ├── css/style.css
│   ├── js/app.js
│   └── vendor/       # Bootstrap 5.3.2 (MIT) embarqué : fonctionnement hors ligne
├── tests/            # Tests automatisés
├── backups/          # Copies créées avant migration (créé si nécessaire)
└── gardes.db         # Base de données (créée au premier lancement)
```

Tables : `admin`, `workers`, `categories`, `absences`, `shifts`, `settings` (+ `shift_log`, journal des modifications),
avec clés primaires/étrangères, contraintes `CHECK` (ex. agent journalier ⇒ catégorie obligatoire) et index.

---

## 8. Dépannage

| Problème | Solution |
|---|---|
| « Python est introuvable » | Réinstallez Python en cochant *Add python.exe to PATH*, puis relancez `run.bat`. |
| Le port 5000 est déjà utilisé | Fermez l'autre instance (ou le programme qui occupe le port 5000). |
| Mot de passe oublié | Arrêtez l'application, puis dans le dossier du projet : `python -c "import sqlite3; from werkzeug.security import generate_password_hash as g; c=sqlite3.connect('gardes.db'); c.execute('UPDATE admin SET username=?, password_hash=?, must_change=1', ('admin', g('admin'))); c.commit()"` — vous retrouvez `admin` / `admin`. |
| Garde « Non couverte » | Aucun agent disponible : ajoutez un agent, raccourcissez une absence, ou remplacez manuellement. |

Licences tierces : Bootstrap 5.3.2 (MIT), Flask (BSD), OpenPyXL (MIT), ReportLab (BSD).
