@echo off
REM ============================================================
REM  Gestion des Gardes de Nuit - lancement sous Windows 10/11
REM  Double-cliquez sur ce fichier pour demarrer l'application.
REM ============================================================
setlocal
cd /d "%~dp0"
title Gestion des Gardes de Nuit

REM --- 1. Recherche de Python 3 ---
set "PY="
py -3 --version >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if not defined PY (
  python --version >nul 2>nul
  if not errorlevel 1 set "PY=python"
)
if not defined PY (
  echo.
  echo [ERREUR] Python 3 est introuvable.
  echo Installez Python 3.9 ou plus recent depuis https://www.python.org/downloads/
  echo et cochez "Add python.exe to PATH" pendant l'installation.
  echo.
  pause
  exit /b 1
)

REM --- 2. Environnement virtuel (cree une seule fois) ---
if not exist "venv\Scripts\python.exe" (
  echo Creation de l'environnement virtuel...
  %PY% -m venv venv
  if errorlevel 1 (
    echo [ERREUR] Impossible de creer l'environnement virtuel.
    pause
    exit /b 1
  )
)
set "VPY=venv\Scripts\python.exe"

REM --- 3. Dependances (installees seulement si elles manquent) ---
"%VPY%" -c "import flask, openpyxl, reportlab" >nul 2>nul
if errorlevel 1 (
  echo Installation des dependances ^(connexion Internet necessaire la premiere fois^)...
  "%VPY%" -m pip install --disable-pip-version-check -r requirements.txt
  if errorlevel 1 (
    echo [ERREUR] L'installation des dependances a echoue.
    pause
    exit /b 1
  )
)

REM --- 4. Demarrage (la base gardes.db est migree, jamais recreee) ---
echo.
echo Application disponible sur http://127.0.0.1:5000
echo Fermez cette fenetre ou appuyez sur Ctrl+C pour arreter.
echo.
"%VPY%" app.py
if errorlevel 1 (
  echo.
  echo [ERREUR] L'application s'est arretee de maniere inattendue.
)
pause
