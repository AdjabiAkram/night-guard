"""
scheduler.py - Moteur de génération des plannings de gardes.

Ce module ne contient AUCUN code d'interface (ni Flask, ni HTML). Il est composé de :

1. Des algorithmes PURS (assign_daily, assign_superior) qui travaillent sur des
   structures Python simples. Ils sont faciles à tester (voir tests/).
2. Des fonctions d'orchestration qui lisent / écrivent la base SQLite
   (generate_planning, get_candidates, apply_shift_update, ...).

Règle de rotation (personnel journalier, par catégorie)
-------------------------------------------------------
Pour chaque nuit, parmi les agents ACTIFS de la catégorie et DISPONIBLES
(pas d'absence ce jour-là), on choisit :
  1. un agent différent de celui de la nuit précédente (si possible),
  2. celui dont la dernière garde est la PLUS ANCIENNE (rotation « tourniquet »),
  3. à égalité : celui qui a le moins de gardes, puis le plus petit identifiant.
Comme l'historique antérieur (dernière garde de chaque agent) est relu en base,
la rotation CONTINUE d'une génération à l'autre. Un agent absent est simplement
ignoré ; à son retour sa dernière garde est ancienne : il redevient prioritaire.

Personnel supérieur : même principe mais à l'échelle de la semaine (lundi-dimanche).
"""
from collections import Counter
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from statistics import pstdev

from database import log_shift_change

MAX_PERIOD_DAYS = 731  # garde-fou : 2 ans maximum par génération

DAYS_FR = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"]
MONTHS_FR = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet",
             "août", "septembre", "octobre", "novembre", "décembre"]


class ScheduleError(ValueError):
    """Erreur métier affichable à l'utilisateur."""


# --------------------------------------------------------------------------- #
#  Utilitaires de dates
# --------------------------------------------------------------------------- #
def parse_date(value):
    """Convertit 'AAAA-MM-JJ' (ou un objet date) en date ; lève ScheduleError."""
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    try:
        return datetime.strptime((value or "").strip(), "%Y-%m-%d").date()
    except (ValueError, AttributeError):
        raise ScheduleError("Date invalide (format attendu : AAAA-MM-JJ).")


def daterange(start, end):
    """Itère sur toutes les dates de start à end inclus."""
    d = start
    while d <= end:
        yield d
        d += timedelta(days=1)


def week_start(d):
    """Lundi de la semaine contenant d."""
    return d - timedelta(days=d.weekday())


def format_date_fr(d, with_weekday=True):
    d = parse_date(d)
    text = f"{d.day:02d} {MONTHS_FR[d.month - 1]} {d.year}"
    return f"{DAYS_FR[d.weekday()]} {text}" if with_weekday else text


def weekday_fr(d):
    return DAYS_FR[parse_date(d).weekday()]


# --------------------------------------------------------------------------- #
#  Disponibilités
# --------------------------------------------------------------------------- #
def is_available(absences, worker_id, day):
    """absences : dict worker_id -> liste de (date_debut, date_fin) inclusifs."""
    for start, end in absences.get(worker_id, ()):
        if start <= day <= end:
            return False
    return True


def is_available_range(absences, worker_id, days):
    return all(is_available(absences, worker_id, d) for d in days)


def _lru_key(last, counts):
    """Clé de tri : dernière garde la plus ancienne, puis moins de gardes, puis id."""
    return lambda w: (last.get(w) or date.min, counts.get(w, 0), w)


# --------------------------------------------------------------------------- #
#  Algorithme PUR : personnel journalier (une catégorie)
# --------------------------------------------------------------------------- #
def assign_daily(workers, days, absences, last_assigned=None, counts=None,
                 previous_worker=None, locked=None):
    """
    Retourne {jour: worker_id ou None} pour chaque jour NON verrouillé.

    workers          : liste d'identifiants des agents actifs de la catégorie
    days             : liste ordonnée de dates à planifier
    absences         : {worker_id: [(debut, fin), ...]}
    last_assigned    : {worker_id: date de dernière garde} (historique)
    counts           : {worker_id: nombre de gardes} (historique)
    previous_worker  : agent de garde la nuit précédant la première date
    locked           : {jour: worker_id} affectations conservées (manuelles)
    None = aucune personne disponible -> garde non couverte.
    """
    last = dict(last_assigned or {})
    cnt = dict(counts or {})
    locked = locked or {}
    key = _lru_key(last, cnt)
    result = {}
    prev = previous_worker
    for day in days:
        if day in locked:                       # affectation manuelle conservée
            w = locked[day]
            if w is not None:
                last[w] = day
                cnt[w] = cnt.get(w, 0) + 1
            prev = w
            continue
        available = [w for w in workers if is_available(absences, w, day)]
        if not available:
            result[day] = None                  # garde non couverte
            prev = None
            continue
        # Éviter deux nuits consécutives sauf si aucun autre agent n'est disponible.
        pool = [w for w in available if w != prev] or available
        chosen = min(pool, key=key)
        result[day] = chosen
        last[chosen] = day
        cnt[chosen] = cnt.get(chosen, 0) + 1
        prev = chosen
    return result


# --------------------------------------------------------------------------- #
#  Algorithme PUR : personnel supérieur (rotation hebdomadaire)
# --------------------------------------------------------------------------- #
def assign_superior(workers, weeks, absences, last_week=None, counts=None,
                    previous_worker=None):
    """
    weeks : liste ordonnée de dictionnaires :
        {"start": lundi, "full": [7 dates], "planned": [dates à générer],
         "fixed": agent déjà responsable de cette semaine (ou None),
         "locked_worker": agent des jours verrouillés (ou None)}
    Retourne (assignation {jour: worker_id|None}, avertissements [str]).
    Le même agent garde la responsabilité de toute la semaine.
    """
    last = dict(last_week or {})
    cnt = dict(counts or {})
    key = _lru_key(last, cnt)
    result, warnings = {}, []
    prev = previous_worker
    for wk in weeks:
        planned = wk["planned"]
        fixed = wk.get("fixed")
        if not planned:                         # semaine entièrement verrouillée
            w = wk.get("locked_worker") or fixed
            if w is not None:
                last[w] = wk["start"]
                cnt[w] = cnt.get(w, 0) + 1
                prev = w
            continue

        chosen = None
        # 1) L'agent déjà responsable d'une partie de la semaine la conserve.
        if fixed in workers and is_available_range(absences, fixed, planned):
            chosen = fixed
        else:
            # 2) Agent disponible pendant TOUTE la semaine (lundi -> dimanche).
            full_ok = [w for w in workers if is_available_range(absences, w, wk["full"])]
            pool = [w for w in full_ok if w != prev] or full_ok
            # 3) À défaut : disponible pendant toute la partie planifiée.
            if not pool:
                part_ok = [w for w in workers if is_available_range(absences, w, planned)]
                pool = [w for w in part_ok if w != prev] or part_ok
            if pool:
                chosen = min(pool, key=key)

        label = f"{wk['start'].strftime('%d/%m/%Y')}"
        if chosen is not None:
            for d in planned:
                result[d] = chosen
            last[chosen] = wk["start"]
            cnt[chosen] = cnt.get(chosen, 0) + 1
            prev = chosen
            continue

        # 4) Dernier recours : aucun agent disponible toute la période -> jour par jour.
        used = set()
        for d in planned:
            avail = [w for w in workers if is_available(absences, w, d)]
            if avail:
                w = min(avail, key=key)
                result[d] = w
                used.add(w)
            else:
                result[d] = None
        for w in used:
            last[w] = wk["start"]
            cnt[w] = cnt.get(w, 0) + 1
        if used and None in (result[d] for d in planned):
            warnings.append(f"Semaine du {label} : aucun agent supérieur disponible "
                            "toute la semaine, certains jours ne sont pas couverts.")
        elif used:
            warnings.append(f"Semaine du {label} : aucun agent supérieur disponible "
                            "toute la semaine, la responsabilité est répartie entre plusieurs agents.")
        else:
            warnings.append(f"Semaine du {label} : aucun agent supérieur disponible.")
        if used:
            prev = None
    return result, warnings


# --------------------------------------------------------------------------- #
#  Accès base de données
# --------------------------------------------------------------------------- #
def load_absences(conn):
    """Charge toutes les absences : {worker_id: [(debut, fin), ...]}."""
    out = {}
    for r in conn.execute("SELECT worker_id, start_date, end_date FROM absences"):
        out.setdefault(r["worker_id"], []).append(
            (parse_date(r["start_date"]), parse_date(r["end_date"])))
    return out


@dataclass
class GenerationReport:
    created: int = 0
    kept: int = 0
    uncovered: list = field(default_factory=list)   # [{"date","label"}]
    warnings: list = field(default_factory=list)


def _iso(d):
    return d.isoformat()


def generate_planning(conn, start, end, keep_manual=True,
                      do_daily=True, do_superior=True):
    """
    Génère (ou régénère) le planning entre start et end (inclus).

    - Seules les gardes DANS la période sont remplacées ; tout le reste est conservé.
    - keep_manual=True : les affectations modifiées manuellement sont conservées.
    - Les observations déjà saisies sur un créneau sont reportées sur le nouveau.
    La génération est atomique : en cas d'erreur, rien n'est modifié.
    """
    start, end = parse_date(start), parse_date(end)
    if end < start:
        raise ScheduleError("La date de fin doit être postérieure ou égale à la date de début.")
    if (end - start).days + 1 > MAX_PERIOD_DAYS:
        raise ScheduleError(f"Période trop longue (maximum {MAX_PERIOD_DAYS} jours).")
    if not do_daily and not do_superior:
        raise ScheduleError("Sélectionnez au moins un type de personnel à planifier.")

    days = list(daterange(start, end))
    absences = load_absences(conn)
    report = GenerationReport()

    with conn:  # transaction : commit si tout va bien, rollback sinon
        if do_daily:
            _generate_daily(conn, days, absences, keep_manual, report)
        if do_superior:
            _generate_superior(conn, days, absences, keep_manual, report)
        log_shift_change(
            conn, _iso(start), "all", None, "génération",
            details=(f"Période du {start.strftime('%d/%m/%Y')} au {end.strftime('%d/%m/%Y')} : "
                     f"{report.created} garde(s) créée(s), {report.kept} conservée(s), "
                     f"{len(report.uncovered)} non couverte(s)."))
    return report


def _saved_observations(conn, staff_type, category_id, s_iso, e_iso):
    rows = conn.execute(
        "SELECT shift_date, observation FROM shifts WHERE staff_type=? "
        "AND IFNULL(category_id,0)=IFNULL(?,0) AND shift_date BETWEEN ? AND ? "
        "AND observation IS NOT NULL AND observation <> ''",
        (staff_type, category_id, s_iso, e_iso)).fetchall()
    return {r["shift_date"]: r["observation"] for r in rows}


def _generate_daily(conn, days, absences, keep_manual, report):
    s_iso, e_iso = _iso(days[0]), _iso(days[-1])
    cats = conn.execute("SELECT id, name FROM categories WHERE active = 1 ORDER BY name").fetchall()
    for cat in cats:
        cid = cat["id"]
        workers = [r["id"] for r in conn.execute(
            "SELECT id FROM workers WHERE staff_type='daily' AND category_id=? AND active=1 "
            "ORDER BY id", (cid,))]

        # Historique AVANT la période : continuité de la rotation.
        last, counts = {}, {}
        for r in conn.execute(
                "SELECT worker_id, MAX(shift_date) AS last_d, COUNT(*) AS n FROM shifts "
                "WHERE staff_type='daily' AND category_id=? AND shift_date < ? "
                "AND worker_id IS NOT NULL GROUP BY worker_id", (cid, s_iso)):
            last[r["worker_id"]] = parse_date(r["last_d"])
            counts[r["worker_id"]] = r["n"]
        prev_row = conn.execute(
            "SELECT worker_id FROM shifts WHERE staff_type='daily' AND category_id=? "
            "AND shift_date=?", (cid, _iso(days[0] - timedelta(days=1)))).fetchone()
        previous = prev_row["worker_id"] if prev_row else None

        locked = {}
        if keep_manual:
            for r in conn.execute(
                    "SELECT shift_date, worker_id FROM shifts WHERE staff_type='daily' "
                    "AND category_id=? AND shift_date BETWEEN ? AND ? AND is_manual=1 "
                    "AND worker_id IS NOT NULL", (cid, s_iso, e_iso)):
                locked[parse_date(r["shift_date"])] = r["worker_id"]
        report.kept += len(locked)

        observations = _saved_observations(conn, "daily", cid, s_iso, e_iso)
        # Suppression limitée à la période (jamais en dehors) et hors affectations conservées.
        if keep_manual:
            conn.execute(
                "DELETE FROM shifts WHERE staff_type='daily' AND category_id=? "
                "AND shift_date BETWEEN ? AND ? AND NOT (is_manual=1 AND worker_id IS NOT NULL)",
                (cid, s_iso, e_iso))
        else:
            conn.execute(
                "DELETE FROM shifts WHERE staff_type='daily' AND category_id=? "
                "AND shift_date BETWEEN ? AND ?", (cid, s_iso, e_iso))

        result = assign_daily(workers, days, absences, last, counts, previous, locked)
        for d, wid in result.items():
            conn.execute(
                "INSERT INTO shifts (shift_date, staff_type, category_id, worker_id, observation) "
                "VALUES (?, 'daily', ?, ?, ?)", (_iso(d), cid, wid, observations.get(_iso(d))))
            report.created += 1
            if wid is None:
                report.uncovered.append(
                    {"date": d, "label": f"Personnel journalier - catégorie « {cat['name']} »"})


def _generate_superior(conn, days, absences, keep_manual, report):
    s_iso, e_iso = _iso(days[0]), _iso(days[-1])
    workers = [r["id"] for r in conn.execute(
        "SELECT id FROM workers WHERE staff_type='superior' AND active=1 ORDER BY id")]
    first_ws = week_start(days[0])

    # Historique avant la première semaine générée.
    last, weeks_seen = {}, {}
    for r in conn.execute(
            "SELECT shift_date, worker_id FROM shifts WHERE staff_type='superior' "
            "AND shift_date < ? AND worker_id IS NOT NULL ORDER BY shift_date", (_iso(first_ws),)):
        ws = week_start(parse_date(r["shift_date"]))
        last[r["worker_id"]] = ws
        weeks_seen.setdefault(r["worker_id"], set()).add(ws)
    counts = {w: len(s) for w, s in weeks_seen.items()}
    prev_row = conn.execute(
        "SELECT worker_id FROM shifts WHERE staff_type='superior' AND shift_date < ? "
        "ORDER BY shift_date DESC LIMIT 1", (_iso(first_ws),)).fetchone()
    previous = prev_row["worker_id"] if prev_row else None

    locked = {}
    if keep_manual:
        for r in conn.execute(
                "SELECT shift_date, worker_id FROM shifts WHERE staff_type='superior' "
                "AND shift_date BETWEEN ? AND ? AND is_manual=1 AND worker_id IS NOT NULL",
                (s_iso, e_iso)):
            locked[parse_date(r["shift_date"])] = r["worker_id"]
    report.kept += len(locked)

    # Préparation des semaines (AVANT suppression) : agent déjà responsable ?
    weeks, by_week = [], {}
    for d in days:
        by_week.setdefault(week_start(d), []).append(d)
    period = set(days)
    for ws, wdays in sorted(by_week.items()):
        full = [ws + timedelta(days=i) for i in range(7)]
        planned = [d for d in wdays if d not in locked]
        existing = conn.execute(
            "SELECT shift_date, worker_id FROM shifts WHERE staff_type='superior' "
            "AND shift_date BETWEEN ? AND ? AND worker_id IS NOT NULL",
            (_iso(ws), _iso(ws + timedelta(days=6)))).fetchall()
        holders = [r["worker_id"] for r in existing
                   if parse_date(r["shift_date"]) not in period or parse_date(r["shift_date"]) in locked]
        fixed = Counter(holders).most_common(1)[0][0] if holders else None
        locked_w = Counter(locked[d] for d in wdays if d in locked).most_common(1)
        weeks.append({"start": ws, "full": full, "planned": planned, "fixed": fixed,
                      "locked_worker": locked_w[0][0] if locked_w else None})

    observations = _saved_observations(conn, "superior", None, s_iso, e_iso)
    if keep_manual:
        conn.execute(
            "DELETE FROM shifts WHERE staff_type='superior' AND shift_date BETWEEN ? AND ? "
            "AND NOT (is_manual=1 AND worker_id IS NOT NULL)", (s_iso, e_iso))
    else:
        conn.execute("DELETE FROM shifts WHERE staff_type='superior' AND shift_date BETWEEN ? AND ?",
                     (s_iso, e_iso))

    result, warnings = assign_superior(workers, weeks, absences, last, counts, previous)
    report.warnings.extend(warnings)
    for d, wid in sorted(result.items()):
        conn.execute(
            "INSERT INTO shifts (shift_date, staff_type, category_id, worker_id, observation) "
            "VALUES (?, 'superior', NULL, ?, ?)", (_iso(d), wid, observations.get(_iso(d))))
        report.created += 1
        if wid is None:
            report.uncovered.append({"date": d, "label": "Personnel supérieur"})


# --------------------------------------------------------------------------- #
#  Modification manuelle d'une affectation
# --------------------------------------------------------------------------- #
def _shift_or_error(conn, shift_id):
    shift = conn.execute(
        "SELECT s.*, c.name AS category_name, w.full_name AS worker_name FROM shifts s "
        "LEFT JOIN categories c ON c.id = s.category_id "
        "LEFT JOIN workers w ON w.id = s.worker_id WHERE s.id = ?", (shift_id,)).fetchone()
    if not shift:
        raise ScheduleError("Garde introuvable.")
    return shift


def _week_shift_rows(conn, shift):
    ws = week_start(parse_date(shift["shift_date"]))
    return conn.execute(
        "SELECT id, shift_date, worker_id FROM shifts WHERE staff_type='superior' "
        "AND shift_date BETWEEN ? AND ? ORDER BY shift_date",
        (_iso(ws), _iso(ws + timedelta(days=6)))).fetchall()


def get_candidates(conn, shift_id, whole_week=False):
    """
    Agents pouvant remplacer l'agent actuel : même groupe, même catégorie,
    actifs et disponibles sur TOUTES les dates concernées.
    Retourne [{"id","name","warning"}].
    """
    shift = _shift_or_error(conn, shift_id)
    d = parse_date(shift["shift_date"])
    if shift["staff_type"] == "superior" and whole_week:
        days = [parse_date(r["shift_date"]) for r in _week_shift_rows(conn, shift)]
    else:
        days = [d]
    if shift["staff_type"] == "daily":
        pool = conn.execute(
            "SELECT id, full_name FROM workers WHERE staff_type='daily' AND category_id=? "
            "AND active=1 ORDER BY full_name COLLATE NOCASE", (shift["category_id"],)).fetchall()
    else:
        pool = conn.execute(
            "SELECT id, full_name FROM workers WHERE staff_type='superior' AND active=1 "
            "ORDER BY full_name COLLATE NOCASE").fetchall()
    absences = load_absences(conn)
    out = []
    for w in pool:
        if w["id"] == shift["worker_id"]:
            continue
        if not is_available_range(absences, w["id"], days):
            continue
        warning = ""
        if shift["staff_type"] == "daily":
            near = conn.execute(
                "SELECT 1 FROM shifts WHERE staff_type='daily' AND category_id=? AND worker_id=? "
                "AND shift_date IN (?, ?)",
                (shift["category_id"], w["id"], _iso(d - timedelta(days=1)),
                 _iso(d + timedelta(days=1)))).fetchone()
            if near:
                warning = "garde déjà la nuit précédente ou suivante"
        out.append({"id": w["id"], "name": w["full_name"], "warning": warning})
    return out


def apply_shift_update(conn, shift_id, new_worker_id=None, observation=None,
                       whole_week=False):
    """
    Remplace l'agent (si new_worker_id) et/ou met à jour l'observation.
    Retourne un message de confirmation. Lève ScheduleError si la règle n'est pas respectée.
    """
    shift = _shift_or_error(conn, shift_id)
    messages = []
    with conn:
        if new_worker_id:
            allowed = {c["id"]: c for c in get_candidates(conn, shift_id, whole_week)}
            if new_worker_id not in allowed:
                raise ScheduleError("Cet agent n'est pas compatible ou n'est pas disponible "
                                    "à la date choisie.")
            new_name = conn.execute("SELECT full_name FROM workers WHERE id=?",
                                    (new_worker_id,)).fetchone()["full_name"]
            if shift["staff_type"] == "superior" and whole_week:
                targets = _week_shift_rows(conn, shift)
            else:
                targets = [shift]
            for t in targets:
                old = conn.execute(
                    "SELECT w.full_name FROM shifts s LEFT JOIN workers w ON w.id=s.worker_id "
                    "WHERE s.id=?", (t["id"],)).fetchone()["full_name"]
                conn.execute(
                    "UPDATE shifts SET worker_id=?, is_manual=1, updated_at=datetime('now') "
                    "WHERE id=?", (new_worker_id, t["id"]))
                log_shift_change(conn, t["shift_date"], shift["staff_type"],
                                 shift["category_name"], "remplacement", old, new_name,
                                 "Modification manuelle")
            messages.append(f"Agent remplacé par {new_name}"
                            + (" pour toute la semaine." if len(targets) > 1 else "."))
        if observation is not None:
            observation = observation.strip()
            if len(observation) > 500:
                raise ScheduleError("L'observation est limitée à 500 caractères.")
            if observation != (shift["observation"] or ""):
                conn.execute("UPDATE shifts SET observation=?, updated_at=datetime('now') "
                             "WHERE id=?", (observation or None, shift_id))
                log_shift_change(conn, shift["shift_date"], shift["staff_type"],
                                 shift["category_name"], "observation",
                                 details=observation or "(observation supprimée)")
                messages.append("Observation enregistrée.")
    return " ".join(messages) or "Aucune modification."


# --------------------------------------------------------------------------- #
#  Alertes et statistiques (tableau de bord)
# --------------------------------------------------------------------------- #
def find_uncovered(conn, from_date=None, limit=None):
    sql = ("SELECT s.id, s.shift_date, s.staff_type, c.name AS category_name FROM shifts s "
           "LEFT JOIN categories c ON c.id = s.category_id WHERE s.worker_id IS NULL ")
    params = []
    if from_date:
        sql += "AND s.shift_date >= ? "
        params.append(_iso(from_date))
    sql += "ORDER BY s.shift_date, s.staff_type, c.name"
    if limit:
        sql += f" LIMIT {int(limit)}"
    return conn.execute(sql, params).fetchall()


def find_conflicts(conn, from_date):
    """Gardes futures affectées à un agent devenu absent ou désactivé depuis la génération."""
    return conn.execute(
        "SELECT s.id, s.shift_date, s.staff_type, c.name AS category_name, "
        "w.full_name, w.active, MAX(a.reason) AS reason, COUNT(a.id) AS absent "
        "FROM shifts s JOIN workers w ON w.id = s.worker_id "
        "LEFT JOIN categories c ON c.id = s.category_id "
        "LEFT JOIN absences a ON a.worker_id = s.worker_id "
        "  AND s.shift_date BETWEEN a.start_date AND a.end_date "
        "WHERE s.shift_date >= ? "
        "GROUP BY s.id HAVING absent > 0 OR w.active = 0 ORDER BY s.shift_date",
        (_iso(from_date),)).fetchall()


def spread_stats(values):
    """Statistiques de répartition d'une liste de compteurs."""
    if not values:
        return {"min": 0, "max": 0, "mean": 0.0, "spread": 0, "stdev": 0.0}
    mean = sum(values) / len(values)
    return {"min": min(values), "max": max(values), "mean": round(mean, 2),
            "spread": max(values) - min(values), "stdev": round(pstdev(values), 2)}


def distribution_stats(conn):
    """Répartition des gardes par agent, groupée par catégorie / personnel supérieur."""
    groups = []
    cats = conn.execute("SELECT id, name, active FROM categories ORDER BY name").fetchall()
    for cat in cats:
        rows = conn.execute(
            "SELECT w.id, w.full_name, w.active, COUNT(s.id) AS n FROM workers w "
            "LEFT JOIN shifts s ON s.worker_id = w.id "
            "WHERE w.staff_type='daily' AND w.category_id=? "
            "GROUP BY w.id ORDER BY w.full_name COLLATE NOCASE", (cat["id"],)).fetchall()
        rows = [r for r in rows if r["active"] or r["n"]]
        if not rows:
            continue
        groups.append({"title": f"Catégorie « {cat['name']} »", "unit": "nuit(s)",
                       "rows": rows, "stats": spread_stats([r["n"] for r in rows if r["active"]])})
    rows = conn.execute(
        "SELECT w.id, w.full_name, w.active, "
        "COUNT(DISTINCT date(s.shift_date, 'weekday 0', '-6 days')) AS n FROM workers w "
        "LEFT JOIN shifts s ON s.worker_id = w.id WHERE w.staff_type='superior' "
        "GROUP BY w.id ORDER BY w.full_name COLLATE NOCASE").fetchall()
    rows = [r for r in rows if r["active"] or r["n"]]
    if rows:
        groups.append({"title": "Personnel supérieur", "unit": "semaine(s)", "rows": rows,
                       "stats": spread_stats([r["n"] for r in rows if r["active"]])})
    return groups
