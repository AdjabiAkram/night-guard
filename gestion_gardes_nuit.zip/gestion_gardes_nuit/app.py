"""
app.py - Application web « Gestion des Gardes de Nuit » (Flask).

Ce fichier ne contient que la couche web (routes, formulaires, validation, sécurité).
Toute la logique de génération des plannings est dans scheduler.py.

Lancement :  python app.py   puis ouvrir http://127.0.0.1:5000
"""
import io
import logging
import math
import os
import re
import secrets
import sqlite3
import tempfile
import threading
import time
import webbrowser
from datetime import date, timedelta
from functools import wraps

from flask import (Flask, abort, flash, g, jsonify, redirect, render_template,
                   request, send_file, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

import database
import exports
import scheduler
from scheduler import ScheduleError, format_date_fr, parse_date, weekday_fr

PER_PAGE = 50
MAX_VIEW_DAYS = 366
USERNAME_RE = re.compile(r"^[A-Za-z0-9._@-]{3,50}$")
LOGIN_MAX_FAILS = 5
LOGIN_LOCK_SECONDS = 60
_login_failures = {}  # ip -> (nombre d'échecs, instant du premier échec)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")


def create_app():
    database.init_db()  # migrations (jamais destructives) + valeurs par défaut
    app = Flask(__name__)

    boot = database.get_connection()
    app.secret_key = database.get_setting(boot, "secret_key")
    boot.close()
    app.config.update(
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
        MAX_CONTENT_LENGTH=1024 * 1024,
    )
    register_helpers(app)
    register_security(app)
    register_routes(app)
    register_errors(app)
    return app


# --------------------------------------------------------------------------- #
#  Aides : base de données, filtres Jinja, validation
# --------------------------------------------------------------------------- #
def get_db():
    if "db" not in g:
        g.db = database.get_connection()
    return g.db


def clean_text(value, max_len, required=False, label="Champ"):
    value = re.sub(r"\s+", " ", (value or "").strip())
    if required and not value:
        raise ScheduleError(f"{label} obligatoire.")
    if len(value) > max_len:
        raise ScheduleError(f"{label} : {max_len} caractères maximum.")
    return value


def to_int(value, label="Valeur"):
    try:
        return int(value)
    except (TypeError, ValueError):
        raise ScheduleError(f"{label} invalide.")


def safe_next(target, fallback):
    """N'accepte que des redirections internes (anti open-redirect)."""
    if target and target.startswith("/") and not target.startswith("//") and "\\" not in target:
        return target
    return fallback


def register_helpers(app):
    @app.template_filter("date_fr")
    def date_fr(value):
        return format_date_fr(value) if value else ""

    @app.template_filter("date_short")
    def date_short(value):
        return parse_date(value).strftime("%d/%m/%Y") if value else ""

    @app.template_filter("weekday")
    def weekday(value):
        return weekday_fr(value).capitalize() if value else ""

    @app.template_filter("staff_label")
    def staff_label(value):
        return {"daily": "Journalier", "superior": "Supérieur", "all": "Tous"}.get(value, value)

    @app.context_processor
    def inject_globals():
        ctx = {"today": date.today(), "org_name": "Gardes de nuit", "must_change": False}
        if session.get("admin_id"):
            db = get_db()
            ctx["org_name"] = database.get_setting(db, "org_name", "Mon organisation")
            row = db.execute("SELECT must_change FROM admin WHERE id = 1").fetchone()
            ctx["must_change"] = bool(row and row["must_change"])
        return ctx

    app.jinja_env.globals["csrf_token"] = csrf_token

    @app.teardown_appcontext
    def close_db(_exc):
        db = g.pop("db", None)
        if db is not None:
            db.close()


def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


# --------------------------------------------------------------------------- #
#  Sécurité : authentification globale, CSRF, en-têtes
# --------------------------------------------------------------------------- #
def register_security(app):
    @app.before_request
    def protect():
        endpoint = request.endpoint
        if endpoint == "static":
            return None
        # Protection CSRF de tous les formulaires POST (y compris la connexion).
        if request.method == "POST":
            sent = request.form.get("csrf_token", "")
            expected = session.get("_csrf", "")
            if not sent or not expected or not secrets.compare_digest(sent, expected):
                abort(400, "Jeton de sécurité invalide ou expiré. Rechargez la page et réessayez.")
        # Toutes les pages internes exigent une session administrateur.
        if endpoint != "login" and not session.get("admin_id"):
            if request.path.startswith("/api/"):
                return jsonify(error="Authentification requise"), 401
            return redirect(url_for("login", next=request.full_path.rstrip("?")))
        return None

    @app.after_request
    def secure_headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "same-origin"
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
            "frame-ancestors 'none'; form-action 'self'")
        if request.endpoint != "static":
            resp.headers["Cache-Control"] = "no-store"
        return resp


def register_errors(app):
    def render_error(code, title, message):
        return render_template("error.html", code=code, title=title, message=message), code

    @app.errorhandler(400)
    def e400(e):
        return render_error(400, "Requête invalide", getattr(e, "description", "Requête invalide."))

    @app.errorhandler(404)
    def e404(_e):
        return render_error(404, "Page introuvable", "La page demandée n'existe pas.")

    @app.errorhandler(413)
    def e413(_e):
        return render_error(413, "Requête trop volumineuse", "Les données envoyées sont trop volumineuses.")

    @app.errorhandler(Exception)
    def e500(e):
        from werkzeug.exceptions import HTTPException
        if isinstance(e, HTTPException):
            return render_error(e.code, e.name, e.description)
        app.logger.exception("Erreur interne")
        return render_error(500, "Erreur interne",
                            "Une erreur inattendue s'est produite. Vos données n'ont pas été perdues. "
                            "Réessayez ou consultez la console pour le détail.")


# --------------------------------------------------------------------------- #
#  Routes
# --------------------------------------------------------------------------- #
def register_routes(app):

    def fail(message, endpoint="dashboard", **values):
        flash(message, "danger")
        return redirect(url_for(endpoint, **values))

    # ----------------------------- Authentification ------------------------- #
    @app.route("/login", methods=["GET", "POST"])
    def login():
        db = get_db()
        admin = db.execute("SELECT * FROM admin WHERE id = 1").fetchone()
        if session.get("admin_id") and request.method == "GET":
            return redirect(url_for("dashboard"))
        ip = request.remote_addr or "?"
        if request.method == "POST":
            count, first = _login_failures.get(ip, (0, 0))
            if count >= LOGIN_MAX_FAILS and time.time() - first < LOGIN_LOCK_SECONDS:
                flash("Trop de tentatives. Patientez une minute avant de réessayer.", "danger")
                return render_template("login.html", default_pwd=bool(admin["must_change"])), 429
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            if (secrets.compare_digest(username, admin["username"])
                    and check_password_hash(admin["password_hash"], password)):
                _login_failures.pop(ip, None)
                session.clear()
                session["admin_id"] = 1
                session.permanent = True
                flash("Connexion réussie.", "success")
                return redirect(safe_next(request.args.get("next"), url_for("dashboard")))
            if count == 0 or time.time() - first >= LOGIN_LOCK_SECONDS:
                _login_failures[ip] = (1, time.time())
            else:
                _login_failures[ip] = (count + 1, first)
            flash("Nom d'utilisateur ou mot de passe incorrect.", "danger")
        return render_template("login.html", default_pwd=bool(admin["must_change"]))

    @app.route("/logout", methods=["POST"])
    def logout():
        session.clear()
        flash("Vous êtes déconnecté.", "info")
        return redirect(url_for("login"))

    # ----------------------------- Tableau de bord -------------------------- #
    @app.route("/")
    def dashboard():
        db = get_db()
        today = date.today()
        iso = today.isoformat()
        one = lambda sql, p=(): db.execute(sql, p).fetchone()[0]  # noqa: E731
        stats = {
            "workers": one("SELECT COUNT(*) FROM workers"),
            "active_workers": one("SELECT COUNT(*) FROM workers WHERE active=1"),
            "active_categories": one("SELECT COUNT(*) FROM categories WHERE active=1"),
            "shifts_total": one("SELECT COUNT(*) FROM shifts WHERE worker_id IS NOT NULL"),
            "shifts_upcoming": one("SELECT COUNT(*) FROM shifts WHERE worker_id IS NOT NULL "
                                   "AND shift_date >= ?", (iso,)),
        }
        # Prochaines gardes : les 7 prochaines dates planifiées.
        dates = [r[0] for r in db.execute(
            "SELECT DISTINCT shift_date FROM shifts WHERE shift_date >= ? ORDER BY 1 LIMIT 7", (iso,))]
        upcoming = []
        if dates:
            marks = ",".join("?" * len(dates))
            rows = db.execute(
                f"SELECT s.shift_date, s.staff_type, c.name AS category, w.full_name AS worker "
                f"FROM shifts s LEFT JOIN categories c ON c.id = s.category_id "
                f"LEFT JOIN workers w ON w.id = s.worker_id WHERE s.shift_date IN ({marks}) "
                f"ORDER BY s.shift_date, s.staff_type, c.name", dates).fetchall()
            for d in dates:
                upcoming.append({"date": d, "rows": [r for r in rows if r["shift_date"] == d]})

        alerts = {
            "uncovered": scheduler.find_uncovered(db, today, limit=15),
            "uncovered_total": one("SELECT COUNT(*) FROM shifts WHERE worker_id IS NULL AND shift_date >= ?", (iso,)),
            "conflicts": scheduler.find_conflicts(db, today),
            "empty_categories": db.execute(
                "SELECT c.name FROM categories c WHERE c.active=1 AND NOT EXISTS "
                "(SELECT 1 FROM workers w WHERE w.category_id=c.id AND w.active=1)").fetchall(),
            "no_superior": one("SELECT COUNT(*) FROM workers WHERE staff_type='superior' AND active=1") == 0,
        }
        return render_template("dashboard.html", stats=stats, upcoming=upcoming, alerts=alerts,
                               groups=scheduler.distribution_stats(db))

    # ----------------------------- Personnel -------------------------------- #
    @app.route("/personnel")
    def personnel():
        db = get_db()
        f_type = request.args.get("type", "")
        f_cat = request.args.get("category", "")
        f_status = request.args.get("status", "")
        q = request.args.get("q", "").strip()
        sql = ("SELECT w.*, c.name AS category_name, "
               "(SELECT COUNT(*) FROM shifts s WHERE s.worker_id = w.id) AS n_shifts "
               "FROM workers w LEFT JOIN categories c ON c.id = w.category_id WHERE 1=1 ")
        params = []
        if f_type in ("daily", "superior"):
            sql += "AND w.staff_type = ? "
            params.append(f_type)
        if f_cat.isdigit():
            sql += "AND w.category_id = ? "
            params.append(int(f_cat))
        if f_status in ("0", "1"):
            sql += "AND w.active = ? "
            params.append(int(f_status))
        if q:
            sql += "AND w.full_name LIKE ? ESCAPE '\\' "
            params.append("%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
        sql += "ORDER BY w.staff_type DESC, c.name COLLATE NOCASE, w.full_name COLLATE NOCASE"
        workers = db.execute(sql, params).fetchall()
        categories = db.execute("SELECT id, name, active FROM categories ORDER BY name").fetchall()
        return render_template("personnel.html", workers=workers, categories=categories,
                               f_type=f_type, f_cat=f_cat, f_status=f_status, q=q)

    @app.route("/personnel/save", methods=["POST"])
    def personnel_save():
        db = get_db()
        try:
            wid = request.form.get("id", "")
            name = clean_text(request.form.get("full_name"), 100, True, "Le nom")
            if len(name) < 2:
                raise ScheduleError("Le nom doit contenir au moins 2 caractères.")
            staff_type = request.form.get("staff_type", "")
            if staff_type not in ("daily", "superior"):
                raise ScheduleError("Groupe de personnel invalide.")
            category_id = None
            if staff_type == "daily":
                category_id = to_int(request.form.get("category_id"), "Catégorie")
                cat = db.execute("SELECT id FROM categories WHERE id = ?", (category_id,)).fetchone()
                if not cat:
                    raise ScheduleError("Un agent journalier doit être associé à une catégorie existante.")
            active = 1 if request.form.get("active") else 0

            dup = db.execute(
                "SELECT id FROM workers WHERE full_name = ? COLLATE NOCASE AND staff_type = ? "
                "AND IFNULL(category_id,0) = IFNULL(?,0) AND id <> ?",
                (name, staff_type, category_id, int(wid) if wid.isdigit() else 0)).fetchone()
            if dup:
                raise ScheduleError("Un agent portant ce nom existe déjà dans ce groupe / cette catégorie.")

            with db:
                if wid:
                    wid = to_int(wid)
                    old = db.execute("SELECT * FROM workers WHERE id = ?", (wid,)).fetchone()
                    if not old:
                        raise ScheduleError("Agent introuvable.")
                    changed_group = (old["staff_type"] != staff_type
                                     or (old["category_id"] or 0) != (category_id or 0))
                    if changed_group and db.execute(
                            "SELECT 1 FROM shifts WHERE worker_id = ? LIMIT 1", (wid,)).fetchone():
                        raise ScheduleError(
                            "Cet agent a un historique de gardes : son groupe ou sa catégorie ne peut plus "
                            "être modifié. Désactivez-le puis créez un nouvel agent.")
                    db.execute("UPDATE workers SET full_name=?, staff_type=?, category_id=?, active=? "
                               "WHERE id=?", (name, staff_type, category_id, active, wid))
                    flash("Agent modifié.", "success")
                else:
                    db.execute("INSERT INTO workers (full_name, staff_type, category_id, active) "
                               "VALUES (?, ?, ?, ?)", (name, staff_type, category_id, active))
                    flash("Agent ajouté.", "success")
        except ScheduleError as exc:
            flash(str(exc), "danger")
        return redirect(url_for("personnel"))

    @app.route("/personnel/<int:wid>/toggle", methods=["POST"])
    def personnel_toggle(wid):
        db = get_db()
        with db:
            row = db.execute("SELECT active, full_name FROM workers WHERE id=?", (wid,)).fetchone()
            if not row:
                abort(404)
            db.execute("UPDATE workers SET active = 1 - active WHERE id = ?", (wid,))
        flash(f"{row['full_name']} est maintenant "
              f"{'désactivé' if row['active'] else 'activé'}.", "success")
        return redirect(safe_next(request.form.get("return_url"), url_for("personnel")))

    @app.route("/personnel/<int:wid>/delete", methods=["POST"])
    def personnel_delete(wid):
        db = get_db()
        row = db.execute("SELECT full_name FROM workers WHERE id=?", (wid,)).fetchone()
        if not row:
            abort(404)
        try:
            with db:
                db.execute("DELETE FROM workers WHERE id = ?", (wid,))
            flash(f"Agent « {row['full_name']} » supprimé.", "success")
        except sqlite3.IntegrityError:
            flash(f"« {row['full_name']} » possède un historique de gardes et ne peut pas être "
                  "supprimé (l'historique doit rester intact). Désactivez-le à la place.", "danger")
        return redirect(url_for("personnel"))

    # ----------------------------- Catégories ------------------------------- #
    @app.route("/categories")
    def categories():
        db = get_db()
        rows = db.execute(
            "SELECT c.*, (SELECT COUNT(*) FROM workers w WHERE w.category_id=c.id) AS n_workers, "
            "(SELECT COUNT(*) FROM workers w WHERE w.category_id=c.id AND w.active=1) AS n_active, "
            "(SELECT COUNT(*) FROM shifts s WHERE s.category_id=c.id) AS n_shifts "
            "FROM categories c ORDER BY c.name COLLATE NOCASE").fetchall()
        return render_template("categories.html", categories=rows)

    @app.route("/categories/save", methods=["POST"])
    def categories_save():
        db = get_db()
        try:
            cid = request.form.get("id", "")
            name = clean_text(request.form.get("name"), 60, True, "Le nom de la catégorie")
            desc = clean_text(request.form.get("description"), 200)
            active = 1 if request.form.get("active") else 0
            dup = db.execute("SELECT id FROM categories WHERE name = ? COLLATE NOCASE AND id <> ?",
                             (name, int(cid) if cid.isdigit() else 0)).fetchone()
            if dup:
                raise ScheduleError("Une catégorie portant ce nom existe déjà.")
            with db:
                if cid:
                    cid = to_int(cid)
                    if not db.execute("SELECT 1 FROM categories WHERE id=?", (cid,)).fetchone():
                        raise ScheduleError("Catégorie introuvable.")
                    db.execute("UPDATE categories SET name=?, description=?, active=? WHERE id=?",
                               (name, desc or None, active, cid))
                    flash("Catégorie modifiée.", "success")
                else:
                    db.execute("INSERT INTO categories (name, description, active) VALUES (?, ?, ?)",
                               (name, desc or None, active))
                    flash("Catégorie créée.", "success")
        except ScheduleError as exc:
            flash(str(exc), "danger")
        return redirect(url_for("categories"))

    @app.route("/categories/<int:cid>/toggle", methods=["POST"])
    def categories_toggle(cid):
        db = get_db()
        row = db.execute("SELECT name, active FROM categories WHERE id=?", (cid,)).fetchone()
        if not row:
            abort(404)
        with db:
            db.execute("UPDATE categories SET active = 1 - active WHERE id=?", (cid,))
        flash(f"Catégorie « {row['name']} » "
              f"{'désactivée : elle sera ignorée lors des prochaines générations.' if row['active'] else 'activée.'}",
              "success")
        return redirect(url_for("categories"))

    @app.route("/categories/<int:cid>/delete", methods=["POST"])
    def categories_delete(cid):
        db = get_db()
        row = db.execute("SELECT name FROM categories WHERE id=?", (cid,)).fetchone()
        if not row:
            abort(404)
        try:
            with db:
                db.execute("DELETE FROM categories WHERE id = ?", (cid,))
            flash(f"Catégorie « {row['name']} » supprimée.", "success")
        except sqlite3.IntegrityError:
            flash(f"La catégorie « {row['name']} » contient des agents ou possède un historique de "
                  "gardes : suppression impossible. Désactivez-la à la place.", "danger")
        return redirect(url_for("categories"))

    # ----------------------------- Absences --------------------------------- #
    @app.route("/absences")
    def absences():
        db = get_db()
        f_worker = request.args.get("worker", "")
        f_when = request.args.get("when", "")
        sql = ("SELECT a.*, (julianday(a.end_date) - julianday(a.start_date) + 1) AS n_days, "
               "w.full_name, w.staff_type, c.name AS category_name FROM absences a "
               "JOIN workers w ON w.id = a.worker_id LEFT JOIN categories c ON c.id = w.category_id "
               "WHERE 1=1 ")
        params = []
        if f_worker.isdigit():
            sql += "AND a.worker_id = ? "
            params.append(int(f_worker))
        today = date.today().isoformat()
        if f_when == "current":
            sql += "AND a.start_date <= ? AND a.end_date >= ? "
            params += [today, today]
        elif f_when == "future":
            sql += "AND a.start_date > ? "
            params.append(today)
        elif f_when == "past":
            sql += "AND a.end_date < ? "
            params.append(today)
        sql += "ORDER BY a.start_date DESC, w.full_name COLLATE NOCASE"
        rows = db.execute(sql, params).fetchall()
        workers = db.execute(
            "SELECT w.id, w.full_name, w.staff_type, w.active, c.name AS category_name FROM workers w "
            "LEFT JOIN categories c ON c.id = w.category_id "
            "ORDER BY w.active DESC, w.full_name COLLATE NOCASE").fetchall()
        return render_template("absences.html", absences=rows, workers=workers,
                               f_worker=f_worker, f_when=f_when, today=date.today())

    @app.route("/absences/save", methods=["POST"])
    def absences_save():
        db = get_db()
        try:
            aid = request.form.get("id", "")
            wid = to_int(request.form.get("worker_id"), "Agent")
            if not db.execute("SELECT 1 FROM workers WHERE id=?", (wid,)).fetchone():
                raise ScheduleError("Agent introuvable.")
            start = parse_date(request.form.get("start_date"))
            end = parse_date(request.form.get("end_date"))
            if end < start:
                raise ScheduleError("La date de fin doit être postérieure ou égale à la date de début.")
            if (end - start).days > 3660:
                raise ScheduleError("Une absence ne peut pas dépasser 10 ans.")
            reason = clean_text(request.form.get("reason"), 200)
            with db:
                if aid:
                    aid = to_int(aid)
                    if not db.execute("SELECT 1 FROM absences WHERE id=?", (aid,)).fetchone():
                        raise ScheduleError("Absence introuvable.")
                    db.execute("UPDATE absences SET worker_id=?, start_date=?, end_date=?, reason=? "
                               "WHERE id=?", (wid, start.isoformat(), end.isoformat(), reason or None, aid))
                    flash("Absence modifiée.", "success")
                else:
                    db.execute("INSERT INTO absences (worker_id, start_date, end_date, reason) "
                               "VALUES (?, ?, ?, ?)", (wid, start.isoformat(), end.isoformat(), reason or None))
                    flash("Absence enregistrée.", "success")
            # Prévenir si des gardes déjà planifiées tombent pendant l'absence.
            n = db.execute("SELECT COUNT(*) FROM shifts WHERE worker_id=? AND shift_date BETWEEN ? AND ?",
                           (wid, start.isoformat(), end.isoformat())).fetchone()[0]
            if n:
                flash(f"Attention : {n} garde(s) déjà planifiée(s) pendant cette absence. Régénérez la "
                      "période ou remplacez l'agent depuis la page Planning.", "warning")
        except ScheduleError as exc:
            flash(str(exc), "danger")
        return redirect(url_for("absences"))

    @app.route("/absences/<int:aid>/delete", methods=["POST"])
    def absences_delete(aid):
        db = get_db()
        with db:
            cur = db.execute("DELETE FROM absences WHERE id = ?", (aid,))
        flash("Absence supprimée." if cur.rowcount else "Absence introuvable.",
              "success" if cur.rowcount else "danger")
        return redirect(url_for("absences"))

    # ----------------------------- Planning --------------------------------- #
    def read_period():
        today = date.today()
        start = parse_date(request.values.get("start") or today.isoformat())
        end = parse_date(request.values.get("end") or (today + timedelta(days=29)).isoformat())
        if end < start:
            raise ScheduleError("La date de fin doit être postérieure ou égale à la date de début.")
        return start, end

    @app.route("/planning")
    def planning():
        db = get_db()
        try:
            start, end = read_period()
            if (end - start).days + 1 > MAX_VIEW_DAYS:
                raise ScheduleError(f"L'affichage est limité à {MAX_VIEW_DAYS} jours.")
        except ScheduleError as exc:
            flash(str(exc), "danger")
            today = date.today()
            start, end = today, today + timedelta(days=29)
        s_iso, e_iso = start.isoformat(), end.isoformat()

        rows = db.execute(
            "SELECT s.*, c.name AS category_name, w.full_name AS worker_name FROM shifts s "
            "LEFT JOIN categories c ON c.id = s.category_id "
            "LEFT JOIN workers w ON w.id = s.worker_id "
            "WHERE s.shift_date BETWEEN ? AND ? ORDER BY s.shift_date", (s_iso, e_iso)).fetchall()
        daily = {(r["shift_date"], r["category_id"]): r for r in rows if r["staff_type"] == "daily"}
        cat_ids = {r["category_id"] for r in rows if r["staff_type"] == "daily"}
        categories = [c for c in db.execute("SELECT id, name, active FROM categories ORDER BY name COLLATE NOCASE")
                      if c["active"] or c["id"] in cat_ids]
        days = [d.isoformat() for d in scheduler.daterange(start, end)]

        weeks = []
        for r in (r for r in rows if r["staff_type"] == "superior"):
            ws = scheduler.week_start(parse_date(r["shift_date"]))
            if not weeks or weeks[-1]["start"] != ws:
                weeks.append({"start": ws, "end": ws + timedelta(days=6), "rows": []})
            weeks[-1]["rows"].append(r)
        for wk in weeks:
            names = {r["worker_name"] for r in wk["rows"]}
            wk["label"] = (next(iter(names)) if len(names) == 1 and None not in names
                           else ("Non couvert" if names == {None} else "Plusieurs agents"))
            wk["uncovered"] = any(r["worker_id"] is None for r in wk["rows"])
        n_uncovered = sum(1 for r in rows if r["worker_id"] is None)
        return render_template("planning.html", start=start, end=end, days=days, daily=daily,
                               categories=categories, weeks=weeks, n_shifts=len(rows),
                               n_uncovered=n_uncovered,
                               has_active_cat=any(c["active"] for c in categories))

    @app.route("/planning/generate", methods=["POST"])
    def planning_generate():
        db = get_db()
        try:
            start = parse_date(request.form.get("start"))
            end = parse_date(request.form.get("end"))
            report = scheduler.generate_planning(
                db, start, end,
                keep_manual=bool(request.form.get("keep_manual")),
                do_daily=bool(request.form.get("do_daily")),
                do_superior=bool(request.form.get("do_superior")))
        except ScheduleError as exc:
            flash(str(exc), "danger")
            return redirect(url_for("planning"))
        flash(f"Planning généré du {start.strftime('%d/%m/%Y')} au {end.strftime('%d/%m/%Y')} : "
              f"{report.created} garde(s) créée(s)"
              + (f", {report.kept} affectation(s) manuelle(s) conservée(s)" if report.kept else "") + ".",
              "success")
        if report.uncovered:
            flash(f"{len(report.uncovered)} garde(s) NON COUVERTE(S) : aucun agent disponible. "
                  "Elles sont signalées en rouge dans le planning.", "warning")
        for w in report.warnings:
            flash(w, "warning")
        return redirect(url_for("planning", start=start.isoformat(), end=end.isoformat()))

    @app.route("/planning/shift/<int:sid>/update", methods=["POST"])
    def shift_update(sid):
        db = get_db()
        back = safe_next(request.form.get("return_url"), url_for("planning"))
        try:
            worker_raw = request.form.get("worker_id", "")
            worker_id = to_int(worker_raw, "Agent") if worker_raw else None
            msg = scheduler.apply_shift_update(
                db, sid, worker_id, request.form.get("observation", ""),
                whole_week=bool(request.form.get("whole_week")))
            flash(msg, "success" if msg != "Aucune modification." else "info")
        except ScheduleError as exc:
            flash(str(exc), "danger")
        return redirect(back)

    @app.route("/api/shift/<int:sid>/candidates")
    def api_candidates(sid):
        try:
            cands = scheduler.get_candidates(get_db(), sid, whole_week=request.args.get("whole_week") == "1")
        except ScheduleError as exc:
            return jsonify(error=str(exc)), 404
        return jsonify(candidates=cands)

    # ----------------------------- Historique ------------------------------- #
    @app.route("/history")
    def history():
        db = get_db()
        view = request.args.get("view", "shifts")
        page_raw = request.args.get("page", "1")
        page = max(1, int(page_raw)) if page_raw.isdigit() else 1
        today = date.today()
        f_from = request.args.get("from", "")
        f_to = request.args.get("to", "")
        f_type = request.args.get("type", "")
        f_cat = request.args.get("category", "")
        f_worker = request.args.get("worker", "")
        categories = db.execute("SELECT id, name FROM categories ORDER BY name COLLATE NOCASE").fetchall()
        workers = db.execute("SELECT id, full_name FROM workers ORDER BY full_name COLLATE NOCASE").fetchall()

        if view == "log":
            total = db.execute("SELECT COUNT(*) FROM shift_log").fetchone()[0]
            items = db.execute("SELECT * FROM shift_log ORDER BY id DESC LIMIT ? OFFSET ?",
                               (PER_PAGE, (page - 1) * PER_PAGE)).fetchall()
        else:
            where, params = [], []
            try:
                if f_from:
                    where.append("s.shift_date >= ?")
                    params.append(parse_date(f_from).isoformat())
                if f_to:
                    where.append("s.shift_date <= ?")
                    params.append(parse_date(f_to).isoformat())
            except ScheduleError as exc:
                flash(str(exc), "danger")
                where, params = [], []
            if not f_from and not f_to:
                where.append("s.shift_date < ?")      # par défaut : plannings précédents
                params.append(today.isoformat())
            if f_type in ("daily", "superior"):
                where.append("s.staff_type = ?")
                params.append(f_type)
            if f_cat.isdigit():
                where.append("s.category_id = ?")
                params.append(int(f_cat))
            if f_worker.isdigit():
                where.append("s.worker_id = ?")
                params.append(int(f_worker))
            clause = ("WHERE " + " AND ".join(where)) if where else ""
            total = db.execute(f"SELECT COUNT(*) FROM shifts s {clause}", params).fetchone()[0]
            items = db.execute(
                f"SELECT s.*, c.name AS category_name, w.full_name AS worker_name FROM shifts s "
                f"LEFT JOIN categories c ON c.id = s.category_id "
                f"LEFT JOIN workers w ON w.id = s.worker_id {clause} "
                f"ORDER BY s.shift_date DESC, s.staff_type, c.name LIMIT ? OFFSET ?",
                params + [PER_PAGE, (page - 1) * PER_PAGE]).fetchall()
        pages = max(1, math.ceil(total / PER_PAGE))
        args = {k: v for k, v in request.args.items() if k != "page" and v}
        return render_template("history.html", view=view, items=items, total=total, page=page,
                               pages=pages, args=args, categories=categories, workers=workers,
                               f_from=f_from, f_to=f_to, f_type=f_type, f_cat=f_cat, f_worker=f_worker)

    # ----------------------------- Paramètres ------------------------------- #
    @app.route("/settings")
    def settings():
        db = get_db()
        admin = db.execute("SELECT username, must_change FROM admin WHERE id=1").fetchone()
        return render_template("settings.html", admin=admin,
                               db_version=db.execute("PRAGMA user_version").fetchone()[0],
                               db_path=database.DB_PATH)

    @app.route("/settings/organisation", methods=["POST"])
    def settings_org():
        db = get_db()
        try:
            name = clean_text(request.form.get("org_name"), 100, True, "Le nom de l'organisation")
            with db:
                database.set_setting(db, "org_name", name)
            flash("Nom de l'organisation enregistré.", "success")
        except ScheduleError as exc:
            flash(str(exc), "danger")
        return redirect(url_for("settings"))

    @app.route("/settings/credentials", methods=["POST"])
    def settings_credentials():
        db = get_db()
        admin = db.execute("SELECT * FROM admin WHERE id=1").fetchone()
        try:
            if not check_password_hash(admin["password_hash"], request.form.get("current_password", "")):
                raise ScheduleError("Le mot de passe actuel est incorrect.")
            username = request.form.get("username", "").strip()
            if not USERNAME_RE.match(username):
                raise ScheduleError("Nom d'utilisateur : 3 à 50 caractères (lettres, chiffres, . _ @ -).")
            new_pwd = request.form.get("new_password", "")
            updates = {"username": username}
            if new_pwd or admin["must_change"]:
                if len(new_pwd) < 8:
                    raise ScheduleError("Le nouveau mot de passe doit contenir au moins 8 caractères.")
                if new_pwd != request.form.get("confirm_password", ""):
                    raise ScheduleError("La confirmation ne correspond pas au nouveau mot de passe.")
                if new_pwd.lower() in ("admin", "password", "12345678", username.lower()):
                    raise ScheduleError("Ce mot de passe est trop faible. Choisissez-en un autre.")
                updates["password_hash"] = generate_password_hash(new_pwd)
                updates["must_change"] = 0
            sets = ", ".join(f"{k} = ?" for k in updates)
            with db:
                db.execute(f"UPDATE admin SET {sets}, updated_at = datetime('now') WHERE id = 1",
                           list(updates.values()))
            flash("Identifiants mis à jour.", "success")
        except ScheduleError as exc:
            flash(str(exc), "danger")
        return redirect(url_for("settings"))

    @app.route("/settings/backup", methods=["POST"])
    def settings_backup():
        """Télécharge une copie cohérente de la base de données."""
        fd, tmp = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        try:
            src = sqlite3.connect(database.DB_PATH)
            dst = sqlite3.connect(tmp)
            src.backup(dst)
            dst.close()
            src.close()
            with open(tmp, "rb") as fh:
                data = io.BytesIO(fh.read())
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass
        name = f"sauvegarde_gardes_{date.today().isoformat()}.db"
        return send_file(data, as_attachment=True, download_name=name,
                         mimetype="application/octet-stream")

    # ----------------------------- Exportations ----------------------------- #
    @app.route("/export/<fmt>")
    def export(fmt):
        if fmt not in ("xlsx", "pdf"):
            abort(404)
        try:
            start, end = read_period()
            if (end - start).days + 1 > MAX_VIEW_DAYS:
                raise ScheduleError(f"L'exportation est limitée à {MAX_VIEW_DAYS} jours.")
        except ScheduleError as exc:
            flash(str(exc), "danger")
            return redirect(url_for("planning"))
        db = get_db()
        org = database.get_setting(db, "org_name", "Mon organisation")
        s_iso, e_iso = start.isoformat(), end.isoformat()
        if fmt == "xlsx":
            data = exports.build_xlsx(db, org, s_iso, e_iso)
            mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        else:
            data = exports.build_pdf(db, org, s_iso, e_iso)
            mime = "application/pdf"
        return send_file(io.BytesIO(data), mimetype=mime, as_attachment=True,
                         download_name=f"planning_gardes_{s_iso}_{e_iso}.{fmt}")


app = create_app()

if __name__ == "__main__":
    # Fonctionnement strictement local : 127.0.0.1 uniquement.
    url = "http://10.10.10.1:5000"
    if os.environ.get("GARDES_NO_BROWSER") != "1":
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    print(f"Application disponible sur {url}  (Ctrl+C pour arrêter)")
app.run(host="0.0.0.0", port=5000, debug=False)
